//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Hunny Behavior Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Store information of the hunny blobs
// ============================================================

// Time variables 
private var timer : float = 0.0; 

function Update () 
{	
	// Target blob slows down when the bear tries to pick it up 
	if(BearBehaviourScript.targetBlob == this.transform && BearBehaviourScript.bearState == CharacterState.Eat) 
	{	
		// Increase drag of object 
		this.transform.rigidbody.drag = 5.0; 
		
		// Increment the timer
		timer += Time.deltaTime; 
		
		// After the eat animation has completed, the hunny blob is destroyed 
		if(timer >= 1.5f) 
		{	
			// Reset timer 
			timer = 0.0; 
			
			// Destroy hunny blob 
			Destroy(gameObject); 
		}
		
	}
	
	// If ball falls over the edge, it is destroyed 
	if(transform.position.x >= 600 || transform.position.x <= 0)
	{
		Destroy(gameObject); 
	}
	
}

function Start()
{	
	// Push the hunny blob into the array 
	GameStartScript.hunny.Push(transform); 
}
