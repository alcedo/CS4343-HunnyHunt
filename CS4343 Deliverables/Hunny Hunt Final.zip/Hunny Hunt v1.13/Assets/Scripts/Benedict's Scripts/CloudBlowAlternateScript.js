//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Cloud Blow Alternate Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Manipulate the blow area of the cloud for 
// interaction and trigger with hunny blobs. Specifically for Level 2
// ============================================================

// Force variables 
private var forceX;
private var forceY; 
private var magnitude = 0.05; 
private var finalMagnitude = 0.0; 

function OnTriggerEnter (other : Collider) 
{

	forceX = 1.1 * Mathf.Cos(CloudMinusButtonScript.degree * 2 * CloudTriggerScript.PI / 360); 
	forceY = 0.9 * -Mathf.Sin(CloudMinusButtonScript.degree * 2 * CloudTriggerScript.PI / 360); 
	
	if(other.gameObject.CompareTag("Hunny"))
	{
		// Retrieve information of hunny blob's point mass and add a force to push it along the x-axis 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass"); 
		
		// Apply a gradual increasing force when cloud is blowing northeastward 
		if(CloudMinusButtonScript.degree < 0 && CloudMinusButtonScript.degree >= -60)
		{
			var incrementalForce = CloudMinusButtonScript.degree / -10.0; 
			finalMagnitude = magnitude + incrementalForce * 0.025; 
		}
		else if(CloudMinusButtonScript.degree < -60)
		{
			finalMagnitude = 0.0; 
		}
		else 
		{
			finalMagnitude = magnitude; 
		}
		
		//print(CloudMinusButtonScript.degree); 
	
		forceX = 1.1 * finalMagnitude * Mathf.Cos(CloudMinusButtonScript.degree * 2 * CloudTriggerScript.PI / 360); 
		forceY = 0.9 * finalMagnitude * -Mathf.Sin(CloudMinusButtonScript.degree * 2 * CloudTriggerScript.PI / 360); 
		
		// Add the resultant force to the hunny blob 
		hunnyBlob.pointMass.parent.addForce(new Vector2(forceX, forceY));
	}
	
	if(other.gameObject.CompareTag("StateChange"))
	{
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager"); 
	
		pm.updateEmitterState(ParticleManager.FluidState.Blown, new Vector2(forceX * 3.0f, forceY * 3.0f));
	}			
}