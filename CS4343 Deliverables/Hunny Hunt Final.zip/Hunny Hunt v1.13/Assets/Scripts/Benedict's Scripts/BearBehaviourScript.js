//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Bear Behavior Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Control the movement and behavior of the bear 
// ============================================================

// Movement and distance variables 
var moveSpeed = 1.5; 
static var distance = 0.0; 
private var difference = 0.0; 
private var bestSoFar = 300.0; 

// Time variables 
private var eatTimer : float = 0.0;
private var stunnedTimer : float = 0.0; 

// Boolean variables 
private var faceRight; 
private var doWalk; 

// Verlet integration variable 
private var vi; 

// Variable to store information of a single target blob 
static var targetBlob; 

// Declaration of character states 
enum CharacterState 
{
	Idle = 0, 
	Walk = 1, 
	Eat = 2,
	Stunned = 3, 
	Excited = 4, 
}

// Track the states of the bear 
static var bearState : CharacterState; 

// Animation for the different states 
public var idleAnimation : AnimationClip;
public var walkAnimation : AnimationClip;
public var eatAnimation : AnimationClip; 
public var stunnedAnimation : AnimationClip; 

private var bearAnimation; 

function OnTriggerEnter (other : Collider)
{
	if(other.gameObject.tag == "Bomb")
	{	
		// Bear is stunned
		bearState = CharacterState.Stunned; 
	}
}

function Update () 
{	
	
	// Idle bear walks if he detects a hunny blob
	if(bearState == CharacterState.Idle) 
	{
		IdleToWalk(); 
	}	
	// Bear walks to the hunny blob and attempt to eat it
	else if(bearState == CharacterState.Walk) 
	{
		WalkToEat(); 
	}
	// Hunny blob is successfully eaten or hunny blob has gone out of range 
	else if(bearState == CharacterState.Eat) 
	{
		EatToIdle(); 
	}
	// Bear is stunned by bomb dropped by bird
	else if(bearState == CharacterState.Stunned)
	{
		Stunned(); 
	}
	
}
	
function IdleToWalk ()
{	
	// Play eat animation
	bearAnimation.Play(idleAnimation.name); 
	bearAnimation.CrossFade(idleAnimation.name);	
	
	// Retrieve information from the physics body script 
	var hunnyList = vi.getPhysicsBodyList(); 
	var hunnyCount = vi.getPhysicsBodyList().Count; 
	
	// Find a hunny blob to walk to and pick up 
	for (var hunnyBlob: PhysicsBody in hunnyList)
	{	
		if (hunnyBlob != null && hunnyBlob.center.y <= 3.0) 
		{
			// Retrieve information of the hunny blob 
			targetBlob = hunnyBlob; 

			// Bear is walking to the hunny blob and should not be disrupted 
			bearState = CharacterState.Walk; 
		}
	} 
	
	/*// Find a hunny blob to walk to and pick up 
	for (var hunnyBlob: PhysicsBody in hunnyList)
	{	
		if (hunnyBlob != null && hunnyBlob.center.y <= 3.0) 
		{	
			// Check the difference between the bear and hunny blob) 
			difference = Mathf.Abs(transform.position.x - hunnyBlob.center.x); 
			
			// Find hunny blobs which are nearer to the bear 
			if(difference < bestSoFar)
			{
				targetBlob = hunnyBlob; 
				bestSoFar = difference; 
			}
		}
	} 
	
	bearState = CharacterState.Walk;
	bestSoFar = 300.0;*/
	
}

function WalkToEat () 
{	
	if(!GameStartScript.inGameMenu) {

		// Set flag to true 
		if(!doWalk)
		{
			doWalk = true; 
		}
		// Bear walks toward hunny blob and stops when it reaches the hunny blob 
		else 
		{		
			// Play walk animation
			bearAnimation.Play(walkAnimation.name); 
			bearAnimation.CrossFade(walkAnimation.name);	
		
			// Determine the direction of movement 
			var rawDistance = targetBlob.center.x - transform.position.x; 
			
			// Find out the remaining distance left between the bear and the hunny blob 
			var remainingDistance = Mathf.Abs(rawDistance); 
	
			// Bear will eat the hunny blob when it is near 
			if(remainingDistance <= 3.0) 
			{
				bearState = CharacterState.Eat;
				Destroyer.destroyBody(vi.getPointMassList(), vi.getConstraintList(), vi.getPhysicsBodyList(), targetBlob); 
				doWalk = false; 
			}
			// Bear stops if it is near the edge 
			else if(transform.position.x >= 140) 
			{
				bearState = CharacterState.Idle; 
				doWalk = false; 
			}
			// Else if it's still far away, it continues walking 
			else 
			{	
				// Move forward or backward along the x axis depending on the position of the hunny blob 
				if(rawDistance >= 0)
				{
					if(faceRight) 
					{
						transform.position.x += moveSpeed; 
					}
					else 
					{	
						// Decrement angle of bear 
						transform.eulerAngles.y--;
						
						// Hide help UI when bear is turning 
						transform.Find("UI Help").renderer.enabled = false; 
						transform.Find("UI Help/Bubble 1").renderer.enabled = false; 
						transform.Find("UI Help/Bubble 2").renderer.enabled = false; 
						transform.Find("UI Help/Bubble 3").renderer.enabled = false; 
						transform.Find("UI Help/Help Text").renderer.enabled = false; 
						
						// Set flag to true when it is facing right 
						if(transform.eulerAngles.y <= 90) 
						{
							faceRight = true; 
							
							// Make help UI appear appropriately 
							transform.Find("UI Help").transform.localEulerAngles.y = 270; 
							transform.Find("UI Help").transform.localPosition.z = -5; 
						} 
					}
				}
				else
				{
					if(!faceRight)
					{
						transform.position.x -= moveSpeed; 
					}
					else 
					{	
						// Increment angle of bear 
						transform.eulerAngles.y++;
						
						// Hide help UI when bear is turning 
						transform.Find("UI Help").renderer.enabled = false; 
						transform.Find("UI Help/Bubble 1").renderer.enabled = false; 
						transform.Find("UI Help/Bubble 2").renderer.enabled = false; 
						transform.Find("UI Help/Bubble 3").renderer.enabled = false; 
						transform.Find("UI Help/Help Text").renderer.enabled = false; 
						
						// Set flag to false when it is facing left 
						if(transform.eulerAngles.y >= 270) 
						{
							faceRight = false;  
							
							// Make help UI appear appropriately 
							transform.Find("UI Help").transform.localEulerAngles.y = 90; 
							transform.Find("UI Help").transform.localPosition.z = 5; 
						} 
					}
				}
			}
		} 
	}
}

function EatToIdle () 
{
	// Play eat animation
	bearAnimation.Play(eatAnimation.name); 
	bearAnimation.CrossFade(eatAnimation.name);	
	
	// Increment the timer 
	eatTimer += Time.deltaTime;
	
	// After the eat animation has completed, bear goes back to idle 
	if(eatTimer >= 2.0f)
	{	
		// Reset timer 
		eatTimer = 0.0; 
		
		// Change bear state to idle
		bearState = CharacterState.Idle; 
	}
	
}

function Stunned ()
{
	bearAnimation.Play(stunnedAnimation.name);
	bearAnimation.CrossFade(stunnedAnimation.name); 
	
	// Increment the timer 
	stunnedTimer += Time.deltaTime; 
	
	// Bear is stunned for a few seconds and returns to idle after recovery 
	if(stunnedTimer >= 5.0f)
	{
		// Reset timer 
		stunnedTimer = 0.0; 
		
		// Change bear state to idle
		bearState = CharacterState.Idle; 
	}
}

function Start () 
{	
	// Bear is idle when the game starts 
	bearState = CharacterState.Idle; 
	
	// Bear is facing right when the game starts 
	faceRight = true; 
	
	// Bear is not walking when idle
	doWalk = false; 
	
	// Invoke verlet integration script
	vi = Camera.main.GetComponent("VerletIntegration");
	
}

function Awake () {
	
	// Enable animations 
	bearAnimation = GetComponent(Animation);
	
}
