//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Bear Platform Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Handle all interactions on the platform for Level 2 
// ============================================================

function OnTriggerEnter (other : Collider)
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		// Retrieve the blob's properties 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass");
		
		// Lock the blob position 
		hunnyBlob.pointMass.lockXPos(other.gameObject.transform.position.x); 
		hunnyBlob.pointMass.lockYPos(other.gameObject.transform.position.y);
	}
}