//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Background Texture Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Make the background texture display correctly 
// according to screen resolution which the user plays the game in 
// ============================================================

function Start ()
{
	// Determine the dimensions of the texture according to screen resolution and place it in the middle of the screen space 
	guiTexture.pixelInset = Rect (-Screen.currentResolution.width/2, -Screen.currentResolution.height/2, Screen.currentResolution.width, Screen.currentResolution.height); 
}