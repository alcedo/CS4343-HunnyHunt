//function OnTriggerStay(other : Collider) 
//{
//	
//	// Code to check collisions on a platform.
//	// print("OnTriggerEnter: " + other.gameObject); 

//	var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
//	// First way to lock pos
//	handShakeobj.pointMass.lockYPos(other.gameObject.transform.position.y);
//	// Second way to lock pos
//	// handShakeobj.pointMass.lockYPos(handShakeobj.pointMass.pos.y);
//	 handShakeobj.pointMass.addForce(new Vector2(0.005, 0.15f));
//	
//	
//	// Destroy PhysicsBody Object connected to the pointMass which is collided
//	// Note: In case there is a compile error "Destroyer class not found" --
//	// Move verlet folder into standard assets folder. This will let the unity compiler compile the necessary C#
//	// Scripts first
//	// Todo: Check what happens when 2 point mass of the same body told destroy at the same time	
//	
//	/*var vi = Camera.main.GetComponent("VerletIntegration");
//	var pointMassList = vi.pointMassList;
//	var constraintList = vi.constraintList;
//	var phyBodyList = vi.physicsBodyList;
//	var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
//	Destroyer.destroyBody(pointMassList, constraintList, phyBodyList, handShakeobj.pointMass.parent);*/
//}	

var directionRight = true;
var reducedForce = false;

function OnTriggerEnter(other : Collider)
{
    // Code to check collisions on a platform.
	// print("OnTriggerEnter: " + other.gameObject); 
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
		// First way to lock pos
		handShakeobj.pointMass.lockYPos(other.gameObject.transform.position.y);
		// Second way to lock pos
		// handShakeobj.pointMass.lockYPos(handShakeobj.pointMass.pos.y);
		// handShakeobj.pointMass.addForce(new Vector2(0.05, 0.15f));
		
		if(directionRight) {
			
			if(reducedForce) {
				handShakeobj.pointMass.parent.addForce(new Vector2(0.014, 0.04));
			}
		   	
		   	else {
		    	handShakeobj.pointMass.parent.addForce(new Vector2(0.028, 0.04));
		    }
		   
		}
		
		else {
			if(reducedForce) {
				handShakeobj.pointMass.parent.addForce(new Vector2(-0.014, 0.04));
			}
		   	
		   	else {
		    	handShakeobj.pointMass.parent.addForce(new Vector2(-0.028, 0.04));
		    }
		}	
	}
	
	if (other.gameObject.CompareTag("StateChange"))
	{
		//print("StateChangeEnteredTriggered" + other.gameObject.transform.parent.name);
		// update state of the physics body to drop
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager");
		
		if (directionRight) {
			pm.updateEmitterState(ParticleManager.FluidState.PlatformRight);
		}
		
		else {
			pm.updateEmitterState(ParticleManager.FluidState.PlatformLeft);
		}
	}
}


function OnTriggerExit(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
		handShakeobj.pointMass.unlockYPos();
	}
	
	if (other.gameObject.CompareTag("StateChange"))
	{
		//print("StateChangeExitTriggered" + other.gameObject.transform.parent.name);
		// update state of the physics body to drop
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager");
		pm.updateEmitterState(ParticleManager.FluidState.Falling);
	}
}