//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Table Rebound Script
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Rebound hunny blobs in the opposite direction when
// it collides with the table 
// ============================================================

var reboundForce = -0.5; 

function OnTriggerEnter (other : Collider) 
{	
	if(other.gameObject.GetComponent("HandShakePointMass"))
	{
		// Retrieve information of hunny blob's point mass and add a force to push it along the x-axis 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass"); 
	
		// Add the resultant force to the hunny blob 
		hunnyBlob.pointMass.addForce(new Vector2(reboundForce, 0.0)); 
	}	
}