//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles 
//============================================================
// Cloth Support Trigger Script  
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Hunny blobs roll off the support platform 
// realistically 
// ============================================================

var goToLeft = false; 

function OnTriggerEnter (other : Collider)
{ 
	if(other.gameObject.CompareTag("Hunny"))
	{
		// Retrieve information of hunny blob's point mass 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass");
		
		hunnyBlob.pointMass.lockYPos(other.gameObject.transform.position.y);
	}		
}

function OnTriggerStay (other : Collider) 
{
	if(other.gameObject.CompareTag("Hunny"))
	{
		// Retrieve information of hunny blob's point mass 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass");
		
		if(!goToLeft)
		{
			hunnyBlob.pointMass.addForce(new Vector2(0.025, 0.025)); 
		}
		else 
		{
			hunnyBlob.pointMass.addForce(new Vector2(-0.025, 0.025)); 
		}
	}
}

function OnTriggerExit (other : Collider) 
{
	if(other.gameObject.CompareTag("Hunny"))
	{
		// Retrieve information of hunny blob's point mass 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass");
		
		hunnyBlob.pointMass.unlockYPos(); 
	}
}