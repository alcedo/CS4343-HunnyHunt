private var timer : float; 
private var color : Color = Color(1, 0, 0, 0.1); 

function OnTriggerEnter (other : Collider) 
{	
	if(other.gameObject.CompareTag("Hunny"))
	{
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass");
		hunnyBlob.pointMass.lockXPos(other.gameObject.transform.position.x);
		hunnyBlob.pointMass.lockYPos(other.gameObject.transform.position.y);
	}	
}

function OnTriggerStay (other : Collider)
{
	if(other.gameObject.CompareTag("Hunny")) 
	{
		var handShakeObj = other.gameObject.GetComponent("HandShakePointMass"); 
		
		if(handShakeObj.pointMass.pos.x < renderer.bounds.min.x)
		{
			handShakeObj.pointMass.pos.x = renderer.bounds.min.x+5; 
		}
		
		if(handShakeObj.pointMass.pos.x > renderer.bounds.max.x)
		{
			handShakeObj.pointMass.pos.x = renderer.bounds.max.x-5; 
		}
		
		if(handShakeObj.pointMass.pos.y < renderer.bounds.min.y)
		{
			handShakeObj.pointMass.pos.y = renderer.bounds.min.y+5; 
		}
		
		if(handShakeObj.pointMass.pos.y > renderer.bounds.max.y)
		{
			handShakeObj.pointMass.pos.y = renderer.bounds.max.y-5; 
		}
	}
}

function Update () {

	timer += Time.deltaTime;
	
	if(timer >= 1.0f)
	{
		// Method to create Verlet Integration hunny blobs 
		var vi = Camera.main.GetComponent("VerletIntegration");
		//vi.addBodyOnMouseClick(158, 100, 5, true);
		
		timer = 0.0;
	}

}

function Start () 
{
	var mesh : Mesh = GetComponent(MeshFilter).mesh;
	print(renderer.bounds.min.x + " " + renderer.bounds.max.x); 
	print(mesh.bounds.min.x + " " + mesh.bounds.max.x); 
	renderer.material.color = color; 
}