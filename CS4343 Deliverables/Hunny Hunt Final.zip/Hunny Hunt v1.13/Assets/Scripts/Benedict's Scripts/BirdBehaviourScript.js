//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Bird Behaviour Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Spawn birds at the bird house and control movement
// of the birds
// ============================================================

// Prefab assignment for the bird
private var bird; 
var birdPrefab : Transform; 

// Movement variables 
var moveSpeed : float = 1.0; 

// Distance variables 
var moveToTreeX : float = 50.0; 
var moveToTreeY : float = 100.0;

// Time variables 
private var idleTimer : float = 0.0; 
private var flapTimer : float = 0.0; 

// Flags to track state of bird
private var birdSpawned = false; 
private var flapWings = true; 

// States of the bird 
enum BirdState 
{
	Spawn = 0,
	Idle = 1,
	Fly = 2, 
}

// Track the state of the bird 
private var birdState : BirdState;

function SpawnToIdle () 
{	
	// Increment timer
	flapTimer += Time.deltaTime; 
	
	if(!birdSpawned)
	{
		// Create a bird 
		bird = Instantiate(birdPrefab, new Vector3(-28.0, 70.0, 0.0), Quaternion.identity); 
		birdSpawned = true; 
	}
	
	var descent = moveSpeed * Time.deltaTime; 
	
	if(flapTimer >= 0.25f) 
	{
		if(flapWings)
		{	
			// Flap left wing
			bird.transform.Find("Left Wing").transform.Translate(0, 0.5, 0.5, Space.World); 
			bird.transform.Find("Left Wing").transform.Rotate(-45, 0, 0, Space.World); 
		
			// Flap right wing
			bird.transform.Find("Right Wing").transform.Translate(0, 0.5, -0.5, Space.World); 
			bird.transform.Find("Right Wing").transform.Rotate(45, 0, 0, Space.World);
		
			//Return to original position next
			flapWings = false; 
		}
		else 
		{
			// Return to original position of left wing 
			bird.transform.Find("Left Wing").transform.Translate(0, -0.5, -0.5, Space.World); 
			bird.transform.Find("Left Wing").transform.Rotate(45, 0, 0, Space.World); 
		
			// Return to original position of right wing 
			bird.transform.Find("Right Wing").transform.Translate(0, -0.5, 0.5, Space.World); 
			bird.transform.Find("Right Wing").transform.Rotate(-45, 0, 0, Space.World);
		
			// Flap wings next 
			flapWings = true; 
		}
		
		// Reset timer
		flapTimer = 0.0; 
		
	}
	
	if(bird.transform.position.y > 41)
	{
		bird.transform.Translate(0.0, -descent, 0.0); 
	}
	else
	{
		birdState = BirdState.Idle; 
	}
}

function IdleToFly () 
{	
	// Increment timer
	idleTimer += Time.deltaTime; 
	
	// Once the bird has been idle for awhile, it starts to fly 
	if(idleTimer >= 1.0f)
	{
		birdState = BirdState.Fly; 
		idleTimer = 0.0; 
	}
}

function Fly () 
{
	// Increment timer
	flapTimer += Time.deltaTime; 
	
	// Move bird along x-axis 
	var distance = moveSpeed * Time.deltaTime; 
 
	// Bird is descending down to bird house from treetop
	if(bird.transform.position.x < 100 && bird.transform.position.y > 20.0)
	{
		bird.transform.Translate(distance, -distance, 0.0);
	}
	// Bird is moving beyond hunny pot into the palm tree
	else if(bird.transform.position.x >= 100)
	{
		var distX = moveToTreeX * Time.deltaTime; 
		var distY = moveToTreeY * Time.deltaTime; 
		
		bird.transform.Translate(distX, distY, 0.0); 
	}
	// Bird is moving across the plane 
	else 
	{
		bird.transform.Translate(distance, 0.0, 0.0);
	}

	if(flapTimer >= 0.25f) 
	{
		if(flapWings)
		{	
			// Flap left wing
			bird.transform.Find("Left Wing").transform.Translate(0, 0.5, 0.5, Space.World); 
			bird.transform.Find("Left Wing").transform.Rotate(-45, 0, 0, Space.World); 
		
			// Flap right wing
			bird.transform.Find("Right Wing").transform.Translate(0, 0.5, -0.5, Space.World); 
			bird.transform.Find("Right Wing").transform.Rotate(45, 0, 0, Space.World);
		
			//Return to original position next
			flapWings = false; 
		}
		else 
		{
			// Return to original position of left wing 
			bird.transform.Find("Left Wing").transform.Translate(0, -0.5, -0.5, Space.World); 
			bird.transform.Find("Left Wing").transform.Rotate(45, 0, 0, Space.World); 
		
			// Return to original position of right wing 
			bird.transform.Find("Right Wing").transform.Translate(0, -0.5, 0.5, Space.World); 
			bird.transform.Find("Right Wing").transform.Rotate(-45, 0, 0, Space.World);
		
			// Flap wings next 
			flapWings = true; 
		}
		
		// Reset timer
		flapTimer = 0.0; 
		
	}
	
	// Reset all values after bird has reached palm tree 
	if(bird.transform.position.x >= 140)
	{
		Destroy(bird.gameObject); 
		birdSpawned = false; 
		birdState = BirdState.Spawn;
	}
	
}

function Update () 
{
	if(birdState == BirdState.Spawn)
	{
		SpawnToIdle();
	}
	else if(birdState == BirdState.Idle) 
	{	
		IdleToFly();
	}
	else if(birdState == BirdState.Fly)
	{
		Fly(); 
	}
}

function Start () 
{
	// Invoke verlet integration script
	vi = Camera.main.GetComponent("VerletIntegration");

	// Bird spawns when the game starts 
	birdState = BirdState.Spawn; 
}