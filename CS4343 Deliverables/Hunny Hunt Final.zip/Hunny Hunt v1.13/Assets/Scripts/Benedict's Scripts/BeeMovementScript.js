//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Bee Movement Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Control the movement of the worker bees from the 
// beehive to the dispatch point where honey blobs drop 
// ============================================================

// Prefab assignment for the honey blobs 
var blob; 
var blobPrefab : Transform; 

// Position variables 
var startPoint : float = -38.0; 
var dispatchPoint : float = 10.0; 

// Time variables 
private var timer : float = 0.0; 
private var hunnyReleaseTimer: float = 0.0;

// Flags to track state of bee 
private var flapWings = true; 
private var moveToDispatchPoint = true; 

var dropHunnyBee = false;

function Update () {
	
	// Increment the timer
	timer += Time.deltaTime; 
	hunnyReleaseTimer +=  Time.deltaTime; 
	
	
	if(timer >= 0.25f)
	{
		
		if(flapWings) 
		{
			// Flap left wing 
			transform.Find("Left Wing").transform.Translate(-0.8, 0, 0, transform); 
			transform.Find("Left Wing").transform.Rotate(0, -90, 0, Space.World); 
		
			// Flap right wing
			transform.Find("Right Wing").transform.Translate(-0.8, 0, 0, transform); 
			transform.Find("Right Wing").transform.Rotate(0, 90, 0, Space.World); 
		
			// Return to original position
			flapWings = false; 
		}
		else 
		{
			// Return to original position of left wing 
			transform.Find("Left Wing").transform.Translate(0.8, 0, 0, transform); 
			transform.Find("Left Wing").transform.Rotate(0, 90, 0, Space.World); 
		
			// Return to original position of right wing 
			transform.Find("Right Wing").transform.Translate(0.8, 0, 0, transform); 
			transform.Find("Right Wing").transform.Rotate(0, -90, 0, Space.World); 
		
			// Flap wings 
			flapWings = true; 
		}
		
		
		// Reset timer 
		timer = 0.0; 
		
	}
	
	// Once level starts, bee begins to move 
	if(GameStartScript.levelStart && dropHunnyBee) 
	{
		var translation_x : float = GameStartScript.beeMovementSpeed * Time.deltaTime; 
	
		if(moveToDispatchPoint)
		{
			transform.Translate(translation_x, 0, 0, Space.World); 
		} 
		else 
		{
			transform.Translate(-translation_x, 0, 0, Space.World); 
		}
	}
	
	// Release 1 hunny blob when bee reaches the dispatch point 
	if(transform.position.x >= dispatchPoint && dropHunnyBee)
	{		
		if(GameStartScript.levelStart && GameStartScript.hunnyReleased < GameStartScript.maxHunny && ((hunnyReleaseTimer) > 1.0)) 
		{
			/*
			// Method to create dummy hunny blobs 
			blob = Instantiate(blobPrefab, transform.Find("Spawn Point").transform.position, Quaternion.identity); 
			blob.tag = "Hunny"; 
			*/
			
			// Method to create Verlet Integration hunny blobs 
			var vi = Camera.main.GetComponent("VerletIntegration");
			vi.addBodyOnMouseClick(transform.position.x, transform.position.y -0.5, 5, false);
			
			// Update game variables 
			hunnyReleaseTimer = 0.0;
			GameStartScript.hunnyReleased ++;
		}
		
		// Update flag for bee to move back to beehive 
		moveToDispatchPoint = false;
		
	}
	
	// Move bee to dispatch point if bee reaches beehive 
	if(transform.position.x <= startPoint)
	{
		moveToDispatchPoint = true; 
	}

}