//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles 
//============================================================
// Catapult Fire Script  
// 
// Author: Lim Fang Wei Benedict 
//
// Description: When player clicks on the "Fire" button, the 
// catapult is activate and flings the hunny blobs 
// ============================================================

// Boolean flags 
static var onFire = false; 

// Triggers cannon when cannon is clicked on 
function OnMouseDown ()
{	
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		onFire = true;
	} 
}

// Resets flag when left mouse button is up 
function OnMouseUp ()
{	
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		onFire = false;
	}
}

function OnMouseOver () 
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		transform.localScale.x = 0.98;
		transform.localScale.z = 0.98;
	}
}

function OnMouseExit () 
{
	transform.localScale.x = 0.9;
	transform.localScale.z = 0.9;
}