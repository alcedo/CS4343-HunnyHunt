//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Camera Movement Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Allows user to pan the camera in the x & y axes
// as well as zoom in and out along the z axis to view the game world
// ============================================================

// Movement variables
var moveSpeed : float = 10.0;
var zoomSpeed : float = 1.0; 

// Limit variables 
var upBoundary : float = 500.0; 
var downBoundary : float = 0.0; 
var leftBoundary : float = 0.0; 
var rightBoundary : float = 500.0; 
var frontBoundary : float = 0.0; 
var backBoundary : float = 1000.0; 

function Update () {
	
	// Determine the values of translation along the x & y axes
	var translation_x : float = Input.GetAxis("Horizontal") * moveSpeed;
	var translation_y : float = Input.GetAxis ("Vertical") * moveSpeed;
	
	// User holds onto the "a" or "d" key to move the camera left or right 
	if(Input.GetKey("a") || Input.GetKey("d"))
	{
		// Move translation along the x-axis
		transform.Translate (translation_x, 0, 0);
	}
	
	// User holds onto the "w" or "s" key to move the camera up or down 
	if(Input.GetKey("w") || Input.GetKey("s"))
	{
		// Move translation along the y-axis
		transform.Translate (0, translation_y, 0);
	}
	
	// User holds onto the "q" key to zoom in the game scene 
	if(Input.GetKey("q"))
	{	
		if(camera.orthographicSize > frontBoundary)
		{
			// Decrease camera's orthographic size to zoom in the game scene 
			camera.orthographicSize -=  zoomSpeed; 
		}
	}
	
	// User holds onto the "e" key to zoom out the game scene 
	if(Input.GetKey("e"))
	{	
		if(camera.orthographicSize < backBoundary)
		{
			// Increase camera's orthographic size to zoom out the game scene 
			camera.orthographicSize +=  zoomSpeed; 
		}
	}
	
}