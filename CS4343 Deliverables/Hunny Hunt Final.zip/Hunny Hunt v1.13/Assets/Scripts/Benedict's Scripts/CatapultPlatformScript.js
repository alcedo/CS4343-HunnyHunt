//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles 
//============================================================
// Catapult Platform Script  
// 
// Author: Lim Fang Wei Benedict 
//
// Description: When catapult reaches its maximum capacity, 
// excess blobs fall down and roll off the platform 
// ============================================================

/*
function OnTriggerStay (other : Collider) 
{
	if(other.gameObject.CompareTag("Hunny"))
	{
		var handShakeObj = other.gameObject.GetComponent("HandShakePointMass");
		handShakeObj.pointMass.lockYPos(other.gameObject.transform.position.y);
			
		// Hunny blob gradually rolls to the edge of the platform 	
		handShakeObj.pointMass.parent.addForce(new Vector2(-0.01, 0.04));
	}
}

function OnTriggerExit (other : Collider)
{
	if(other.gameObject.CompareTag("Hunny"))
	{
		var handShakeObj = other.gameObject.GetComponent("HandShakePointMass");
		
		// Hunny blob rolls off the platform 
		handShakeObj.pointMass.unlockYPos(); 
	}
}
*/

var directionRight = true;

function OnTriggerEnter(other : Collider)
{
    // Code to check collisions on a platform.
	// print("OnTriggerEnter: " + other.gameObject); 
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
		// First way to lock pos
		handShakeobj.pointMass.lockYPos(other.gameObject.transform.position.y);
		// Second way to lock pos
		// handShakeobj.pointMass.lockYPos(handShakeobj.pointMass.pos.y);
		// handShakeobj.pointMass.addForce(new Vector2(0.05, 0.15f));
		
		if(directionRight) {
		
		   // handShakeobj.pointMass.parent.addForce(new Vector2(0.09, 0.15));
		    handShakeobj.pointMass.parent.addForce(new Vector2(0.028, 0.04));
		   
		}
		
		else {
			// handShakeobj.pointMass.parent.addForce(new Vector2(-0.09, 0.15));
			handShakeobj.pointMass.parent.addForce(new Vector2(-0.028, 0.04));
		}	
	}
	
	if (other.gameObject.CompareTag("StateChange"))
	{
		//print("StateChangeEnteredTriggered" + other.gameObject.transform.parent.name);
		// update state of the physics body to drop
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager");
		
		if (directionRight) {
			pm.updateEmitterState(ParticleManager.FluidState.PlatformRight);
		}
		
		else {
			pm.updateEmitterState(ParticleManager.FluidState.PlatformLeft);
		}
	}
}


function OnTriggerExit(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
		handShakeobj.pointMass.unlockYPos();
	}
	
	if (other.gameObject.CompareTag("StateChange"))
	{
		//print("StateChangeExitTriggered" + other.gameObject.transform.parent.name);
		// update state of the physics body to drop
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager");
		pm.updateEmitterState(ParticleManager.FluidState.Falling);
	}
}