//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles 
//============================================================
// Cannon Trigger Script  
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Allow user to click on the cannon to shoot hunny blobs
// ============================================================

// Boolean flag variables 
private var onCannon = false;

// Cannon variables 
static var currentCapacity : int = 0; 
static var maxCapacity : int = 5; 

// Blob variables 
private var numOfPoints = 0; 

// Time variables 
var timer : float = 0.0; 

// Triggers cannon when cannon is clicked on 
function OnMouseDown ()
{	
	onCannon = true;
}

// Resets flag when left mouse button is up 
function OnMouseUp ()
{	
	onCannon = false;
}

// Handle blob behavior when it enters the collider of the cannon 
function OnTriggerEnter (other : Collider) 
{	
	if(currentCapacity < maxCapacity)
	{
		if (other.gameObject.CompareTag("Hunny"))
		{
			// Increment counter
			numOfPoints++; 
			
			// All points of the blob structure has been triggered 
			if(numOfPoints == 4) 
			{
				// Increase the current capacity 
				currentCapacity++; 
				
				// Invoke the verlet integration script
				var vi = Camera.main.GetComponent("VerletIntegration");
		
				// Retrieve information from the component lists 
				var pointMassList = vi.pointMassList;
				var constraintList = vi.constraintList;
				var phyBodyList = vi.physicsBodyList;
		
				// Destroy every component of the collided blob systematically 
				var handShakeObj = other.gameObject.GetComponent("HandShakePointMass");
				Destroyer.destroyBody(pointMassList, constraintList, phyBodyList, handShakeObj.pointMass.parent);
			
				// Reset counter
				numOfPoints = 0; 
			}
		}			
	}		
}

function OnTriggerStay (other : Collider) 
{
	if(currentCapacity >= maxCapacity)
	{	
		if (other.gameObject.CompareTag("Hunny"))
		{
			var handShakeObj = other.gameObject.GetComponent("HandShakePointMass");
			
			// Stop blob from falling into the cannon 
			handShakeObj.pointMass.lockYPos(other.gameObject.transform.position.y);
			
			// Gradually push the blob away from the cannon 
			handShakeObj.pointMass.addForce(new Vector2(-0.05, 0.0)); 
		}
	}
}

function OnTriggerExit (other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeObj = other.gameObject.GetComponent("HandShakePointMass");
			
		// Allow blob to fall freely
		handShakeObj.pointMass.unlockYPos();
	}
}

function Update () 
{	
	timer += Time.deltaTime; 
	
	/*if(timer >= 1.0f)
	{
		var vl = Camera.main.GetComponent("VerletIntegration"); 
		vl.addBodyOnMouseClick(115, 60); 
		timer = 0.0; 
	} */

	// If there is ammo in the cannon, shoot it when it is clicked on
	if(Input.GetMouseButtonDown(0) && onCannon && currentCapacity > 0) 
	{	
		// Method to create Verlet Integration hunny blobs 
		var vi = Camera.main.GetComponent("VerletIntegration");
		
		// Create a blob at the cannon barrel 
		vi.addBodyOnMouseClick(transform.Find("Spawn Point").transform.position.x, transform.Find("Spawn Point").transform.position.y);
		
		// Decrease current capacity by 1 
		currentCapacity--; 
	}
}