//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Cloud Blow Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Manipulate the blow area of the cloud for 
// interaction and trigger with hunny blobs 
// ============================================================

// Force variables 
private var forceX;
private var forceY; 
var magnitude = 0.12; 

function OnTriggerEnter (other : Collider) 
{

	forceX = magnitude * Mathf.Cos(CloudMinusButtonScript.degree * 2 * CloudTriggerScript.PI / 360); 
	forceY = magnitude * -Mathf.Sin(CloudMinusButtonScript.degree * 2 * CloudTriggerScript.PI / 360); 
		
	if(other.gameObject.CompareTag("Hunny"))
	{
		// Retrieve information of hunny blob's point mass and add a force to push it along the x-axis 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass"); 
	
		// Add the resultant force to the hunny blob 
		hunnyBlob.pointMass.parent.addForce(new Vector2(forceX, forceY));
	}
	
	if(other.gameObject.CompareTag("StateChange"))
	{
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager"); 
		
		if (magnitude == 0.24) 
		{
			pm.updateEmitterState(ParticleManager.FluidState.Blown, new Vector2(forceX, forceY));
		}
		
		else {
			pm.updateEmitterState(ParticleManager.FluidState.Blown, new Vector2(forceX * 2, forceY * 2));
		}
	}		
}