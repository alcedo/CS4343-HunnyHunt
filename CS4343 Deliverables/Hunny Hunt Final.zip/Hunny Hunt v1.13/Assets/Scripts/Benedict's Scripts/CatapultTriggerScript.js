//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles 
//============================================================
// Catapult Trigger Script  
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Allow user to click on the catapult to shoot 
// hunny blobs
// ============================================================

// Boolean flag variables 
private var onCatapult = false;
private var activated = false; 

// Cantapult variables 
static var currentCapacity : int = 0; 
static var maxCapacity : int = 5;  
private var spawnPoint : Vector3;

// Blob variables 
private var numOfPoints = 0; 

// Time variables 
private var timer : float = 0.0; 
private var delayTimer : float = 0.0; 
private var shootSequenceTimer : float = 0.0; 

static var playSound = false;

// Animation variables
public var catapultAnimation : AnimationClip; 

// Triggers cannon when cannon is clicked on 
function OnMouseDown ()
{	
	onCatapult = true;
}

// Resets flag when left mouse button is up 
function OnMouseUp ()
{	
	onCatapult = false;
}

// Handle blob behavior when it enters the collider of the cannon 
function OnTriggerEnter (other : Collider) 
{	
	if(currentCapacity < maxCapacity && other.gameObject.CompareTag("Hunny") && !animation.IsPlaying(catapultAnimation.name))
	{
		// Increment counter
		numOfPoints++; 
		
		// All points of the blob structure has been triggered 
		if(numOfPoints == 4) 
		{
			// Increase the current capacity 
			currentCapacity++; 
			
			// Invoke the verlet integration script
			var vi = Camera.main.GetComponent("VerletIntegration");
	
			// Retrieve information from the component lists 
			var pointMassList = vi.pointMassList;
			var constraintList = vi.constraintList;
			var phyBodyList = vi.physicsBodyList;
	
			// Destroy every component of the collided blob systematically 
			var handShakeObj = other.gameObject.GetComponent("HandShakePointMass");
			Destroyer.destroyBody(pointMassList, constraintList, phyBodyList, handShakeObj.pointMass.parent);
		
			// Reset counter
			numOfPoints = 0; 
		}			
	}		
}

function Update () 
{	
/*
	timer += Time.deltaTime; 
	
	if(timer >= 1.0f)
	{
		var vl = Camera.main.GetComponent("VerletIntegration"); 
		vl.addBodyOnMouseClick(60, 100); 
		timer = 0.0; 
	} 
*/
	// If there is ammo in the cannon, shoot it when it is clicked on
	if(Input.GetMouseButtonDown(0) && CatapultFireScript.onFire && currentCapacity > 0 && !animation.IsPlaying(catapultAnimation.name)) 
	{	
		// Catapult is activated to shoot
		activated = true; 
		playSound = true;
	} 
	
	if(activated)
	{	
		// Play catapult animation
		animation.Play(catapultAnimation.name); 
		
		// Track the timing of the catapult sequence
		shootSequenceTimer += Time.deltaTime; 

		// Release the hunny blob when the catapult lunges forward 
		if(shootSequenceTimer >= 1.0f && currentCapacity > 0)
		{
			delayTimer += Time.deltaTime; 
		
			// Method to create Verlet Integration hunny blobs 
			var vi = Camera.main.GetComponent("VerletIntegration");	
			
			if(delayTimer >= 0.2f)
			{
				// Create a hunny blob
				vi.addBodyOnMouseClick(transform.Find("Spawn Point").transform.position.x, transform.Find("Spawn Point").transform.position.y, 5 , false); 
				
				// Decrease current capacity by 1 
				currentCapacity--; 
				
				delayTimer = 0.0; 
			}				
		}
		
		// Reset flags after animation finishes and hunny blob has been released 
		if(currentCapacity <= 0)//shootSequenceTimer >= 2.0f)
		{
			activated = false;
			delayTimer = 0.0;
			shootSequenceTimer = 0.0; 
		}
	}
	
}

static function catapultReset() {
	currentCapacity = 0;
}