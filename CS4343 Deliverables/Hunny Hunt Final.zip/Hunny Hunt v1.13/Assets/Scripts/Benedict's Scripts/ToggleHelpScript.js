//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Toggle Help Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: UI element which toggles help popups 
// ============================================================

// Boolean flag to track whether help is on or off 
static var helpOn = true; 

function OnMouseOver ()
{
	// GUI text turns to yellow if mouse is over it 
	guiText.material.color = Color.yellow; 
}

function OnMouseExit ()
{
	// GUI text is white if mouse is not over it 
	guiText.material.color = Color.white; 
}

function OnMouseDown ()
{
	// User has pressed on the GUI 
	 if(helpOn)
	 {
		helpOn = false;
		guiText.text = "Help - Off"; 
	}
	else 
	{
		helpOn = true; 
		guiText.text = "Help - On"; 
	}
}