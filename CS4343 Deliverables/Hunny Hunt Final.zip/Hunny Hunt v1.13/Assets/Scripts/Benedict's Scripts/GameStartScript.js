//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Game Start Script
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Initialize data structures for the game 
// ============================================================

static var level = 1;
static var levelStart;
static var maxHunny;
static var hunnyReleased;
static var hunnyCollected;
static var hunnyGoal;
static var beeMovementSpeed:float;
static var hunny; 
static var ammo; 

static var inGameMenu;
static var resume;
static var restart;
static var returnToMain;

private var timer :float = 0.0;

function Awake () {
	

	
	if(level == 1) {
		maxHunny = 30;
		hunnyReleased = 0;
		hunnyCollected = 0;
		hunnyGoal = 20;
		beeMovementSpeed = 15.0;
	}	
	resetLevel();
	inGameMenu = false;
	resume = false;
	restart = false;
	returnToMain = false;
	levelStart = false;
}

static function newLevel(num) {

	level = num;
	Application.LoadLevel(level);
	switch (level){
		
		// Initialize variables 
		case 1:
			maxHunny = 30;
			hunnyReleased = 0;
			hunnyCollected = 0;
			hunnyGoal = 1;
			beeMovementSpeed = 15.0;
			break;
			
		case 2:
			maxHunny = 25;
			hunnyReleased = 0;
			hunnyCollected = 0;
			hunnyGoal = 15;
			beeMovementSpeed = 15.0;
			break;
	
		default :
			break;
	}
	resetLevel();
	
	inGameMenu = false;
	resume = false;
	restart = false;
	returnToMain = false;
	levelStart = false;
	
}

function Update() {

	//timer += Time.deltaTime;
	timer += 0.01;

	if((Input.GetKey(27)|| Input.GetKey(KeyCode.P)) && levelStart && timer >= 0.2) {
	
		if(inGameMenu) {
			Time.timeScale = 1;
			inGameMenu = false;
			timer = 0.0;
		}
		
		else {
			Time.timeScale = 0.000001;
			inGameMenu = true;
			timer = 0.0;
		}
	
	}
	
	if(Input.GetKey(KeyCode.K) || Input.GetKey(KeyCode.L)) {
	
		if(Input.GetKey(KeyCode.L)) {
			LevelLightControlScript.lightValue += 0.01;
		}
		
		else {
			LevelLightControlScript.lightValue -= 0.01;
		}
	
	}
	
	if (Input.GetKey(KeyCode.U)) {
	
		newLevel(2);
	}
	
	if(inGameMenu) {
	
		if(resume) {
			Time.timeScale = 1;
			inGameMenu = false;
			timer = 0.2;
			resume = false;
		}
		
		if(restart) {
			Time.timeScale = 1;
			//resetLevel();
			//Application.LoadLevel(level);
			newLevel(level);
			
		}
		
		if(returnToMain) {
			Time.timeScale = 1;
			resetLevel();
			Application.LoadLevel(0);
		}
	
	}
}


static function resetLevel() {
	SunSliderScript.sunReset();
	CatapultTriggerScript.catapultReset();
	CloudTriggerScript.cloudReset();
	CloudMinusButtonScript.cloudMinusReset();
	ReadyGoScript.resetTimer();
	MsgToPlayerScript.msgReset();
}