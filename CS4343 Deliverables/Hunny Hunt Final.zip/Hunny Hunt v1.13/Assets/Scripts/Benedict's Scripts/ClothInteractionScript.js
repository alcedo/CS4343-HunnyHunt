//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles 
//============================================================
// Cloth Interaction Script  
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Simulate realistic interaction between the cloth
// and the hunny blobs. The cloth tears when there are too many 
// hunny blobs. 
// ============================================================

// Time variables 
private var testTimer : float;
private var destroyTimer: float;  

// Boolean flags 
private var destroy = false; 

// Update variables
private var numOfPoints : int = 0;
private var hunnyCollided : int = 0; 

// Cloth variables 
private var tearThreshold : int = 20; 
private var incrementalForceX : float; 
private var incrementalForceY : float;
private var incrementalForceZ : float; 

// Collider variables 
private var colliderY = -0.5; 

// Force variables 
var forceX : float = 0.0; 
var forceY : float = -500000.0;
var forceZ : float = 0.0; 
var forceRadius = 25.0;

function OnTriggerEnter (other : Collider)
{ 
	if(other.gameObject.CompareTag("Hunny") && !destroy)
	{
		// Retrieve information of hunny blob's point mass and add a force to push it along the x-axis 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass");
		
		// Give the hunny blob a small upward force to simulate a trampoline-like effect 
		hunnyBlob.pointMass.addForce(new Vector2(0.0, 1.5)); 
		
		numOfPoints++; 
		
		// 1 hunny blob has hit the cloth 
		if(numOfPoints == 5) 
		{
			hunnyCollided++; 
			numOfPoints = 0; 
			
			// Get the properties of the collider attached to the cloth 
			var boxCollider = GetComponent(BoxCollider); 
	
			// Move collider down when cloth bends in order to bring hunny blobs as close to it as possible 
			boxCollider.center = Vector3(0.0, colliderY, 0.0); 
	
			// Decrease by 0.1 
			colliderY -= 0.075; 
		}
	}		
}

function Update () 
{
	/*
	testTimer += Time.deltaTime;
	
	if(testTimer >= 1.0f)
	{
		// Method to create Verlet Integration hunny blobs 
		var vi = Camera.main.GetComponent("VerletIntegration");
		vi.addBodyOnMouseClick(75, 80, 5, false);
		
		testTimer = 0.0;
	}
	*/ 
	
	// Apply a downward force to the cloth as hunny blobs gather on the cloth 
	transform.GetComponent(Cloth).AddForceAtPosition(new Vector3(hunnyCollided * incrementalForceX, hunnyCollided * incrementalForceY, hunnyCollided * incrementalForceZ), 
																		transform.position, forceRadius, ForceMode.Force);
	
	// If the number of hunny blobs which hit the cloth is beyond the threshold, the cloth tears and hunny blobs fall through 
	if(hunnyCollided >= tearThreshold) 
	{
		// Cloth is destroyed 
		destroy = true; 
		
		// Make sure the cloth breaks! 
		transform.GetComponent(Cloth).AddForceAtPosition(new Vector3(forceX, forceY, forceZ), 
																			transform.position, forceRadius, ForceMode.Force);																	
	}
	
	// Cloth disappears after sometime 
	if(destroy)
	{
		destroyTimer += Time.deltaTime; 
		
		/*if(destroyTimer >= 3.0f)
		{
			transform.renderer.enabled = false; 
		}*/ 
		
		if(destroyTimer >= 0.25f) 
		{
			transform.renderer.material.color.a -= 0.1; 
			destroyTimer = 0.0; 
		}
	}

}

function Start ()
{
	// Determine the incremental forces to apply to the cloth 
	incrementalForceX = forceX / tearThreshold; 
	incrementalForceY = forceY / tearThreshold; 
	incrementalForceZ = forceZ / tearThreshold; 
}