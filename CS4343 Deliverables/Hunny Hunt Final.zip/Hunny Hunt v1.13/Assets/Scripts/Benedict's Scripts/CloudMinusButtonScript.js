//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Cloud Minus Button Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Alternate method to control the cloud because 
// Event.delta is buggy which renders my previous left mouse drag 
// method unworkable 
// ============================================================

// Boolean flag variables 
static var onCloudUI = false;

// Mathematical variables 
static var PI = 3.14159265; 
static var degree : int = 0;

// UI variables
var centerX : float = -12; 
var centerY : float = 34; 
var pointerRadius : float = 7.5; 
var blowRadius : float = 14;
var indicatorRadius : float = 5.1; 

// Triggers cloud UI when it is clicked on 
function OnMouseDown ()
{	
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		onCloudUI = true;
	} 
}

// Resets flag when left mouse button is up 
function OnMouseUp ()
{	
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		onCloudUI = false;
	}
}  

function OnMouseOver () 
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		transform.localScale.x = 0.12;
		transform.localScale.z = 0.12;
	}
}

function OnMouseExit () 
{
		transform.localScale.x = 0.1;
		transform.localScale.z = 0.1;
}

function Update () {

	if(onCloudUI)
	{
		if(degree < 90)
		{
			// Increment degree 
			degree++; 

			// Move the pointer around the UI 
			GameObject.Find("Cloud UI/anglePointer").transform.position.x = pointerRadius * Mathf.Cos(degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Cloud UI/anglePointer").transform.position.y = pointerRadius * -Mathf.Sin(degree  * 2 * PI / 360) + centerY; 
				
			// Rotate pointer to follow the change in angle 
			GameObject.Find("Cloud UI/anglePointer").transform.Rotate(new Vector3(1.0, 0.0, 0.0)); 
		
			// Move the indicator bar according to angle indicated by pointer
			GameObject.Find("Cloud UI/angleIndicator").transform.position.x = indicatorRadius * Mathf.Cos(degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Cloud UI/angleIndicator").transform.position.y = indicatorRadius * -Mathf.Sin(degree * 2 * PI / 360) + centerY; 
			
			// Rotate indicator bar to follow the change in angle
			GameObject.Find("Cloud UI/angleIndicator").transform.Rotate(new Vector3(0.0, 1.0, 0.0)); 
			
			// Move the blow area according to angle indicated by pointer  
			GameObject.Find("Blow Area").transform.position.x = blowRadius * Mathf.Cos(degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Blow Area").transform.position.y = blowRadius * -Mathf.Sin(degree  * 2 * PI / 360) + centerY; 
		
			// Rotate blow area to follow the change in angle 
			GameObject.Find("Blow Area").transform.Rotate(new Vector3(0.0, 0.0, -1.0));
		
			// Move eyes
			GameObject.Find("Cloud Pic/eyeLeft/eyeLeft1").transform.Rotate(0.0, 1.0, 0.0);
			GameObject.Find("Cloud Pic/eyeRight/eyeRight1").transform.Rotate(0.0, 1.0, 0.0);
		}
	}

}

static function cloudMinusReset() {
	degree = 0;
}