private var number = 0; 

function OnTriggerEnter (other : Collider) 
{	
	if(other.gameObject.CompareTag("Hunny"))
	{
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass");
		hunnyBlob.pointMass.lockXPos(other.gameObject.transform.position.x);
		hunnyBlob.pointMass.lockYPos(other.gameObject.transform.position.y);
	}		
}

function OnTriggerStay (other : Collider) 
{
	if(other.gameObject.CompareTag("Hunny")) 
	{
		var handShakeObj = other.gameObject.GetComponent("HandShakePointMass"); 
		
		if(handShakeObj.pointMass.pos.x < renderer.bounds.min.x)
		{
			handShakeObj.pointMass.pos.x = renderer.bounds.min.x+3; 
		}
		
		if(handShakeObj.pointMass.pos.x > renderer.bounds.max.x)
		{
			handShakeObj.pointMass.pos.x = renderer.bounds.max.x-3; 
		}
		
		if(handShakeObj.pointMass.pos.y < renderer.bounds.min.y)
		{
			handShakeObj.pointMass.pos.y = renderer.bounds.min.y+3; 
		}
		
		if(handShakeObj.pointMass.pos.y > renderer.bounds.max.y)
		{
			handShakeObj.pointMass.pos.y = renderer.bounds.max.y-3; 
		}
	}
}

function Update () {
}