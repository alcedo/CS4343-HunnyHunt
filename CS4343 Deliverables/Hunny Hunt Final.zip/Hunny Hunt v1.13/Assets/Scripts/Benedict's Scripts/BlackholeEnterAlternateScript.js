//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Blackhole Enter Alternate Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Specifically for Level 2. Credits to Qiyang for the 
// original script 
// ============================================================

// Array of physics body 
var physicsBodyList = new Array(); 

// Time variables 
var timer : float = 0.0;
var pauseTimer: float = 0.0;

// Boolean flags 
var inList = false;
var enter = false;

function OnTriggerEnter(other : Collider) 
{
	if(enter) {
		WaitForSeconds(0.05);
		//var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
		
		if (other.gameObject.CompareTag("Hunny"))
		{
			var vi = Camera.main.GetComponent("VerletIntegration");
			var pointMassList = vi.pointMassList;
			var constraintList = vi.constraintList;
			var phyBodyList = vi.physicsBodyList;
			var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
			
			for (var pBody : PhysicsBody in physicsBodyList)
			{
				if (pBody != null && pBody == handShakeobj.pointMass.parent)
				{
					inList = true;
				}
			}
			
			if (!inList && timer >= 0.1)
			{
				physicsBodyList.Add(handShakeobj.pointMass.parent);
				Destroyer.destroyBody(pointMassList, constraintList, phyBodyList, handShakeobj.pointMass.parent);
				vi.addBodyOnMouseClick(140, 65, 5, false);
				timer = 0.0;
			}
			inList = false;
			//print("list count" + physicsBodyList.Count);
			//handShakeobjA.pointMass.parent.teleportToPos(64,78);
		}
		
		if (other.gameObject.CompareTag("StateChange"))
		{
		
		}
	}	
}

function Update() {

	timer += Time.deltaTime;
	
	pauseTimer += Time.deltaTime;

	if(pauseTimer > 0.00001) {
		if(enter){
			gameObject.transform.Rotate(Vector3(0, 4, 0));
		}
		
		else{
			gameObject.transform.Rotate(Vector3(0, -4, 0));
		}
		pauseTimer = 0.0;
	}
}