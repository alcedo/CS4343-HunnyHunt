//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Cloud Idle Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Randomly change wind direction if player does not 
// interact with the cloud after sometime 
// ============================================================

// Timer variables 
private var idleTimer : float; 
var triggerTime : float = 1.5f; 

// Mathematical variables 
static var PI = 3.14159265; 

// UI variables

var centerX : float = 14.7; 
var centerY : float = 34.9; 
var pointerRadius : float = 8.8; 
var blowRadius : float = 14;
var indicatorRadius : float = 5.1; 

function Update () {

	if(CloudPlusButtonScript.onCloudUI || CloudMinusButtonScript.onCloudUI)
	{
		idleTimer = 0.0; 
	}
	else 
	{
		idleTimer += Time.deltaTime; 
	}
	
	if(idleTimer >= triggerTime) 
	{
		if(Random.value > 0.5 && CloudMinusButtonScript.degree < 90 && GameStartScript.levelStart)
		{
			
			// Increment degree 
			CloudMinusButtonScript.degree += 2;

			// Move the pointer around the UI 
			GameObject.Find("Cloud UI/anglePointer").transform.position.x = pointerRadius * Mathf.Cos(CloudMinusButtonScript.degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Cloud UI/anglePointer").transform.position.y = pointerRadius * -Mathf.Sin(CloudMinusButtonScript.degree  * 2 * PI / 360) + centerY; 
				
			// Rotate pointer to follow the change in angle 
			GameObject.Find("Cloud UI/anglePointer").transform.Rotate(new Vector3(2.0, 0.0, 0.0)); 
		
			// Move the indicator bar according to angle indicated by pointer
			GameObject.Find("Cloud UI/angleIndicator").transform.position.x = indicatorRadius * Mathf.Cos(CloudMinusButtonScript.degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Cloud UI/angleIndicator").transform.position.y = indicatorRadius * -Mathf.Sin(CloudMinusButtonScript.degree * 2 * PI / 360) + centerY; 
			
			// Rotate indicator bar to follow the change in angle
			GameObject.Find("Cloud UI/angleIndicator").transform.Rotate(new Vector3(0.0, 2.0, 0.0)); 
			
			// Move the blow area according to angle indicated by pointer  
			GameObject.Find("Blow Area").transform.position.x = blowRadius * Mathf.Cos(CloudMinusButtonScript.degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Blow Area").transform.position.y = blowRadius * -Mathf.Sin(CloudMinusButtonScript.degree  * 2 * PI / 360) + centerY; 
		
			// Rotate blow area to follow the change in angle 
			GameObject.Find("Blow Area").transform.Rotate(new Vector3(0.0, 0.0, -2.0));
			
			GameObject.Find("Cloud Pic/eyeLeft/eyeLeft1").transform.Rotate(0.0, 2.0, 0.0);
			GameObject.Find("Cloud Pic/eyeRight/eyeRight1").transform.Rotate(0.0, 2.0, 0.0);
			
		}
		/*
		else 
		{
			// Decrement degree 
			CloudMinusButtonScript.degree--; 

			// Move the pointer around the UI 
			GameObject.Find("Cloud UI/anglePointer").transform.position.x = pointerRadius * Mathf.Cos(CloudMinusButtonScript.degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Cloud UI/anglePointer").transform.position.y = pointerRadius * -Mathf.Sin(CloudMinusButtonScript.degree  * 2 * PI / 360) + centerY; 
				
			// Rotate pointer to follow the change in angle 
			GameObject.Find("Cloud UI/anglePointer").transform.Rotate(new Vector3(-1.0, 0.0, 0.0)); 
		
			// Move the indicator bar according to angle indicated by pointer
			GameObject.Find("Cloud UI/angleIndicator").transform.position.x = indicatorRadius * Mathf.Cos(CloudMinusButtonScript.degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Cloud UI/angleIndicator").transform.position.y = indicatorRadius * -Mathf.Sin(CloudMinusButtonScript.degree * 2 * PI / 360) + centerY; 
			
			// Rotate indicator bar to follow the change in angle
			GameObject.Find("Cloud UI/angleIndicator").transform.Rotate(new Vector3(0.0, -1.0, 0.0)); 
			
			// Move the blow area according to angle indicated by pointer  
			GameObject.Find("Blow Area").transform.position.x = blowRadius * Mathf.Cos(CloudMinusButtonScript.degree * 2 * PI / 360) + centerX; 
			GameObject.Find("Blow Area").transform.position.y = blowRadius * -Mathf.Sin(CloudMinusButtonScript.degree  * 2 * PI / 360) + centerY; 
		
			// Rotate blow area to follow the change in angle 
			GameObject.Find("Blow Area").transform.Rotate(new Vector3(0.0, 0.0, 1.0));
		}
		*/
		
		// Reset timer 
		idleTimer = 0.0; 
		
	}

}