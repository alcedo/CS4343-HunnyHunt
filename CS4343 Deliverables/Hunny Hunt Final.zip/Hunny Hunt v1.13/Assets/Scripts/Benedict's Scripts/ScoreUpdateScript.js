//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Score Update Script
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Update score information using game triggers 
// ============================================================

// Blob variables 
private var numOfPoints : int = 0; 

// Handle blob behavior when it enters the hunny pot 
function OnTriggerEnter (other : Collider) {
	
	// Ensure that collided object is a hunny blob and is entering the hunny pot from the top 
	if(other.gameObject.CompareTag("Hunny"))
	{	
		// Increment number of points 
		numOfPoints++; 
		
		// Hunny pot has detected all 5 points of a single hunny blob 
		if(numOfPoints == 5) 
		{
			// Update score by 1 hunny blob 
			GameStartScript.hunnyCollected++; 
			
			// Reset counter
			numOfPoints = 0; 
			
			// Invoke the verlet integration method 
			var vi = Camera.main.GetComponent("VerletIntegration");
			vi.addBodyOnMouseClick(123, 90, 4, true);
			
			// Retrieve information from the component lists 
			var pointMassList = vi.pointMassList;
			var constraintList = vi.constraintList;
			var phyBodyList = vi.physicsBodyList;
			
			// Destroy the hunny blob by systematically deleting the components 
			var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
			Destroyer.destroyBody(pointMassList, constraintList, phyBodyList, handShakeobj.pointMass.parent);
		}	
	}
	// Hunny blob is colliding against the sides of the hunny pot - it cannot be considered as collected 
	//else if(other.gameObject.GetComponent("HandShakePointMass") != null && other.gameObject.transform.position.y < 5.0)
	//{
		// Retrieve information of hunny blob's point mass and add a force to push it along the x-axis 
	//	var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass"); 
	
		// Push the blob away from the pot
	//	hunnyBlob.pointMass.addForce(new Vector2(-1.0, 0.0)); 
	//}

}
/*
function Start ()
{	
	// Color the font black 
	transform.Find("Label").renderer.material.color = Color.black; 
}
*/