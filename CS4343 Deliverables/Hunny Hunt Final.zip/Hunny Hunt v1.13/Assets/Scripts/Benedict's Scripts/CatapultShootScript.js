//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Cannon Shoot Script
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Attach script to an invisible object with collider
// in front of catapult to trigger with the hunny blob in order to 
// give it a propelling force 
// ============================================================

var catapultForceX = 3.0;
var catapultForceY = 0.0; 

function OnTriggerEnter (other : Collider) 
{	
	if(other.gameObject.CompareTag("Hunny"))
	{
		// Retrieve information of hunny blob's point mass and add a force to push it along the x-axis 
		var hunnyBlob = other.gameObject.GetComponent("HandShakePointMass"); 
		hunnyBlob.pointMass.addForce(new Vector2 (catapultForceX, catapultForceY));
	}		
}