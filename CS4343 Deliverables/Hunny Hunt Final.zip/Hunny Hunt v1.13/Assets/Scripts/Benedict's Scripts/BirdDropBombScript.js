//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Bird Drop Bomb Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: When bird is clicked on, a bomb is dropped 
// ============================================================

// Prefab assignment for the bomb 
private var bomb; 
var bombPrefab : Transform; 

// Boolean flags 
private var dropBomb = false; 
private var droppedBomb = false; 

// Drop bomb when clicked on 
function OnMouseDown ()
{
	dropBomb = true; 
}

// Reset flag when mouse is up 
function OnMouseUp ()
{
	dropBomb = false; 
}

function Update () {

	if(dropBomb && !droppedBomb)
	{	
		// Release a bomb 
		bomb = Instantiate(bombPrefab, transform.Find("Spawn Point").transform.position, Quaternion.identity); 
		bomb.tag = "Bomb"; 
		
		bomb.transform.Rotate(0, 180, 0, Space.World); 
		
		// Bomb has been dropped 
		droppedBomb = true;
	}
	
}