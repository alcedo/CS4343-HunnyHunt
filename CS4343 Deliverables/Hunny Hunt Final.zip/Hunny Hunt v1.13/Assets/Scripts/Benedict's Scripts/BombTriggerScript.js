//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Bomb Trigger Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Handle the trigger events of the bomb dropped by 
// the bird 
// ============================================================

// Explosion prefab
var explosion : Transform; 

function OnTriggerEnter (other : Collider)
{	
	// Bomb explodes when it hits the bear 
	if(other.gameObject.tag == "Bear")
	{	
		var exp = Instantiate(explosion, transform.position, Quaternion.identity); 
		Destroy(gameObject); 
	}
}

function Update ()
{
	// Bomb explodes when it hits the ground 
	if(transform.position.y <= 0.0)
	{
		var exp = Instantiate(explosion, transform.position, Quaternion.identity); 
		Destroy(gameObject); 
	}
}