//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// UI Help Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Control appearance and triggers of UI help 
// ============================================================

// String to store content of text boxes 
private var helpText; 

function OnMouseOver ()
{
	if(MenuOptionsScript.helpOn)
	{
	// Color the text black 
	transform.Find("UI Help/Help Text").renderer.material.color = Color.black; 
	
	// Set the text to be displayed 
	transform.Find("UI Help/Help Text").gameObject.GetComponent(TextMesh).text = helpText; 
	transform.Find("UI Help/Help Text").gameObject.GetComponent(TextMesh).alignment = TextAlignment.Center; 
	
	// Make the UI help appear 
	transform.Find("UI Help").renderer.enabled = true; 
	transform.Find("UI Help/Bubble 1").renderer.enabled = true; 
	transform.Find("UI Help/Bubble 2").renderer.enabled = true; 
	transform.Find("UI Help/Bubble 3").renderer.enabled = true; 
	transform.Find("UI Help/Help Text").renderer.enabled = true; 
	}
}

function OnMouseExit ()
{
	if(MenuOptionsScript.helpOn)
	{
	// UI help disappears if user moves mouse away from object 
	transform.Find("UI Help").renderer.enabled = false; 
	transform.Find("UI Help/Bubble 1").renderer.enabled = false; 
	transform.Find("UI Help/Bubble 2").renderer.enabled = false; 
	transform.Find("UI Help/Bubble 3").renderer.enabled = false; 
	transform.Find("UI Help/Help Text").renderer.enabled = false; 
	}
}

function Start () 
{	
	// Set the content of the text mesh 
	if(transform.name == "Teddy Bear")
	{
		helpText = "The teddy bear" + "\n" + "loves hunny! <3";
	}
	else if(transform.name == "Beehive")
	{
		helpText = "Busy bee at work" + "\n" + (GameStartScript.maxHunny - GameStartScript.hunnyReleased) + " Hunny left!"; 
	}
	else if(transform.name == "Cloud")
	{
		helpText = "Adjust the angle with the" + "\n" + "plus and minus buttons"; 
	}
	else if(transform.name == "Bird House")
	{
		helpText = "Click on the bird" + "\n" + "to drop a bomb!"; 
	}
	else if(transform.name == "Power Bar (Sun)")
	{
		helpText = "Adjust the power bar" + "\n" + "to propel hunny blobs"; 
	}
	else if(transform.name == "BlackHole (Enter)")
	{
		helpText = "When hunny blobs" + "\n" + "enter the black hole...";
	}
	else if(transform.name == "BlackHole (Exit)")
	{
		helpText = "I wonder what comes out" + "\n" + "from the black hole?"; 
	}
	else if(transform.name == "Save The Hunny")
	{
		helpText = "Move it to" + "\n" + "save the hunny blobs!";
	}
	else if(transform.name == "Catapult")
	{
		helpText = "Click on flame button" + "\n" + "to lunge the hunny blobs!"; 
	}
	else if(transform.name == "Hunny Pot")
	{
		helpText = "The hunny pot" + "\n" + "collects the hunny blobs"; 
	}
	else if(transform.name == "Cloth Platform") 
	{
		helpText = "Too many hunny blobs" + "\n" + "breaks the cloth!"; 
	}
}

function Update() {
	if(transform.name == "Beehive")
	{
		helpText = "Busy bee at work" + "\n" + (GameStartScript.maxHunny - GameStartScript.hunnyReleased) + " Hunny left!"; 
	}
}