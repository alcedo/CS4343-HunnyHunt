//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Cloud Trigger Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: Control the cloud UI for triggers and behavior when
// interacting with the hunny blobs 
// ============================================================

// Boolean flag variables 
static var onCloudUI = false;
static var overCloudUI = false;

// Mathematical variables 
static var PI = 3.14159265; 
static var degree : int = 0;
static var orientation = 1; 

// UI variables
var centerX : float = -12; 
var centerY : float = 34; 
var pointerRadius : float = 7.5; 
var blowRadius : float = 14;
var indicatorRadius : float = 5.1; 

// Mouse variables 
private var mouseButton; 
private var currentPos; 
private var currentMousePos; 
private var difference : Vector2; 

// States of circle in terms of quadrants
enum CircleState 
{
	firstQuadrant = 0, 
	secondQuadrant = 1, 
	thirdQuadrant = 2,
	fourthQuadrant = 3, 
}

// Track the states of the cloud UI  
static var circleState : CircleState; 

// Triggers cloud UI when it is clicked on 
/*function OnMouseDown ()
{	
	onCloudUI = true; 
}

// Resets flag when left mouse button is up 
function OnMouseUp ()
{	
	onCloudUI = false;
} */ 

// Update cloud UI according to mouse position altered by user input 
function OnMouseOver () 
{	
	overCloudUI = true;

	if(Input.GetMouseButton(0))
	{	
		onCloudUI = true; 
		mouseButton = 0;
	}
	else if(Input.GetMouseButton(1))
	{
		onCloudUI = true; 
		mouseButton = 1; 
	}
	else
	{
		onCloudUI = false; 
	}

	if(onCloudUI)
	{	
		// Get mouse position in world coordinates and not screen pixel coordinates
		//currentMousePos = Input.mousePosition;
		//currentMousePos.z = 1.0;
		//currentPos = Camera.main.ScreenToWorldPoint(currentMousePos);	
		
		if(mouseButton == 0)
		{
			degree++;
			orientation = 1; 
		}
		else if(mouseButton == 1)
		{
			degree--; 
			orientation = -1; 
		}
		
		/*// Increment or decrement angle depending on the user's mouse movement 
		if(circleState == CircleState.firstQuadrant)
		{
			if(difference.x > 0 || difference.y < 0)
			{
				degree--; 
				orientation = -1; 
			
				if(degree < 0)
				{
					degree += 360; 
					print(degree + " Crossed to 4th quadrant from 1st quadrant"); 
				}
			
				print(degree + " decreasing in 1st quadrant"); 
			}
			else 
			{
				degree++;
				orientation = 1; 
				print(degree + " increasing in 1st quadrant"); 
			} 
		}
		else if (circleState == CircleState.secondQuadrant)
		{
			if(difference.x > 0|| difference.y > 0)
			{
				degree--; 
				orientation = -1; 
				print(degree + " decreasing in 2nd quadrant"); 
			}
			else {
				degree++;
				orientation = 1; 
				print(degree + " increasing in 2nd quadrant"); 
			}
		}
		else if(circleState == CircleState.thirdQuadrant)
		{
			if(difference.x < 0|| difference.y > 0)
			{
				degree--;
				orientation = -1; 
				print(degree + " decreasing in 3rd quadrant"); 
			}
			else 
			{
				degree++;
				orientation = 1; 
				print(degree + " increasing in 3rd quadrant"); 
			}
		} 
		else if(circleState == CircleState.fourthQuadrant)
		{
			if(difference.x < 0 || difference.y < 0)
			{
				degree--; 
				orientation = -1; 
				print(degree + " decreasing in 4th quadrant"); 
			}
			else {
				degree++;
				orientation = 1; 
				
				print(degree + " increasing in 4th quadrant"); 	
			
				// Reset degree to 0 if it reaches or exceeds 360
				if(degree >= 360)
				{
					degree = degree % 360; 
					print(degree + " Crossed to 1st quadrant from 4th quadrant"); 
				}	
			}
		}*/ 
		
		// Move the pointer around the UI 
		transform.position.x = pointerRadius * Mathf.Cos(degree * 2 * PI / 360) + centerX; 
		transform.position.y = pointerRadius * -Mathf.Sin(degree  * 2 * PI / 360) + centerY; 
				
		// Rotate pointer to follow the change in angle 
		transform.Rotate(new Vector3(orientation, 0.0, 0.0)); 
		
		// Move the indicator bar according to angle indicated by pointer
		GameObject.Find("angleIndicator").transform.position.x = indicatorRadius * Mathf.Cos(degree * 2 * PI / 360) + centerX; 
		GameObject.Find("angleIndicator").transform.position.y = indicatorRadius * -Mathf.Sin(degree * 2 * PI / 360) + centerY; 
			
		// Rotate indicator bar to follow the change in angle
		GameObject.Find("angleIndicator").transform.Rotate(new Vector3(0.0, orientation, 0.0)); 
			
		// Move the blow area according to angle indicated by pointer  
		GameObject.Find("Blow Area").transform.position.x = blowRadius * Mathf.Cos(degree * 2 * PI / 360) + centerX; 
		GameObject.Find("Blow Area").transform.position.y = blowRadius * -Mathf.Sin(degree  * 2 * PI / 360) + centerY; 
		
		// Rotate blow area to follow the change in angle 
		GameObject.Find("Blow Area").transform.Rotate(new Vector3(0.0, 0.0, -orientation));
	}
	onCloudUI = false;
}

function OnMouseExit() {
	overCloudUI = false;
}

/*// Triggers when user clicks and drag the cloud UI pointer
function OnGUI () 
{
	if(Event.current.type == EventType.MouseDrag)
	{
		difference = Event.current.delta; 
	}
}*/ 

function Update () 
{
	if(!onCloudUI) {
	
		overCloudUI = false;
	}
	/*if(degree >= 0 && degree < 90)
	{
		circleState = CircleState.firstQuadrant;
	}
	else if(degree >= 90 && degree < 180)
	{
		circleState = CircleState.secondQuadrant;
	}
	else if(degree >= 180 && degree < 270)
	{
		circleState = CircleState.thirdQuadrant;
	}
	else if(degree >= 270 && degree < 360)
	{
		circleState = CircleState.fourthQuadrant; 
	}*/ 
}

static function cloudReset () {
	degree = 0;
	orientation = 1;
}