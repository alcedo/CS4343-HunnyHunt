//============================================================
// CS4343 Phase 2 AY10/11 Semester 2 
// Hunny Hunt by Team 4BOTtles
//============================================================
// Bee Dispatch Script 
// 
// Author: Lim Fang Wei Benedict 
//
// Description: When bear is stunned, bees will spawn and rescue 
// the hunny blobs 
// ============================================================

// Prefab assignment for bee 
private var bee;  
var beePrefab : Transform;

// Blob variables 
private var targetBlob; 

// Other variables 
private var moveSpeed : float = 1.0; 
private var distance; 

// Boolean variables 
private var hasSearched = false; 

// Verlet integration variables 
private var vi; 

enum RescueState
{
	Idle = 1,
	Fly = 2,
	Reached = 3,
	Rescue = 4,
}

private var rescueState : RescueState; 

function Update () 
{
	if(BearBehaviourScript.bearState == CharacterState.Stunned)
	{
		// Retrieve information from the physics body script 
		var hunnyList = vi.getPhysicsBodyList(); 
		var hunnyCount = vi.getPhysicsBodyList().Count; 

		if(!hasSearched)
		{	
			// Find a hunny blob to fly to and pick up 
			for (var hunnyBlob: PhysicsBody in hunnyList)
			{	
				if (hunnyBlob != null && hunnyBlob.center.y <= 3.0 && !hasSearched) 
				{	
					targetBlob = hunnyBlob;

					bee = Instantiate(beePrefab, transform.Find("Spawn Point").transform.position, Quaternion.identity);

					distance = new Vector2(targetBlob.center.x - bee.transform.position.x, targetBlob.center.y - bee.transform.position.y);  
					
					rescueState = RescueState.Fly; 
					
					hasSearched = true; 

				}
			}
		}	
		else 
		{
			if(rescueState == RescueState.Fly)
			{
				// Move proportionately according to the difference in distances 
				var moveX = distance.x * moveSpeed * Time.deltaTime; 
				var moveY = distance.y * moveSpeed * Time.deltaTime;

				// Translate the bee 
				bee.transform.Translate(moveX, moveY, 0.0);
				
				// Find distance between current bee position and blob 
				var distX = Mathf.Abs(bee.transform.position.x - targetBlob.center.x);
				var distY = Mathf.Abs(bee.transform.position.y - targetBlob.center.y);
				
				if(distX <= 1.0 && distY <= 1.0)
				{
					rescueState = RescueState.Reached; 
				}
			}
			else if(rescueState == RescueState.Reached)
			{
				// Move in the y-axis 
				var ascent = 10 * moveSpeed * Time.deltaTime; 
				
				// Hunny blob is "destroyed"
				Destroyer.destroyBody(vi.getPointMassList(), vi.getConstraintList(), vi.getPhysicsBodyList(), targetBlob); 
				
				// Bee "carries" hunny blob upwards
				bee.transform.Translate(0.0, ascent, 0.0);
				
				if(bee.transform.position.y >= 20.0)
				{
					rescueState = RescueState.Rescue; 
				}
				
			}
			else if(rescueState == RescueState.Rescue)
			{
				// Move in the x-axis 
				var dist = 10 * moveSpeed * Time.deltaTime; 
				
				// Bee hovers over hunny pot 
				bee.transform.Translate(dist, 0.0, 0.0);
				
				if(bee.transform.position.x >= 115.0)
				{
					// Create a blob 
					vi.addBodyOnMouseClick(bee.transform.Find("Spawn Point").transform.position.x, bee.transform.Find("Spawn Point").transform.position.y);
					
					// Reset all variables 
					rescueState = RescueState.Idle; 
					hasSearched = false; 
					
					// Destroy bee 
					Destroy(bee.gameObject); 
				}
				
			}
		}
	}
}

function Start ()
{
	// Invoke verlet integration script
	vi = Camera.main.GetComponent("VerletIntegration");
	
	rescueState = RescueState.Idle; 
}