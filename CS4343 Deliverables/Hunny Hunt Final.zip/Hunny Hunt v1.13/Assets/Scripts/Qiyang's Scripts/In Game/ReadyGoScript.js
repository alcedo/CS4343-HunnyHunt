// Script controls the countdown timer before the level starts

static var timer : float = 0.0;

static function resetTimer() {
	timer = 0.0;
}

function Update() {

	timer += Time.deltaTime;
	
	if (timer < 0.25) {
		
		guiText.enabled = false;
	
	}
	
	else {
	
		guiText.enabled = true;
	}
	
	if( timer < 1.25f) {
		guiText.transform.position.x = 0.2;
		guiText.fontSize = 45;
		guiText.material.color = Color.cyan;
		guiText.text = "Collect at least " + GameStartScript.hunnyGoal.ToString() + " Hunny Blobs";
	}
	
	else if ( timer < 2.25f) {
		guiText.transform.position.x = 0.4;
		guiText.fontSize = 45;
		guiText.material.color = Color.red;
		guiText.text = "READY...";
	}
	
	else if ( timer < 3.00f) {
		guiText.transform.position.x = 0.4;
		guiText.fontSize = 45;
		guiText.material.color = Color.yellow;
		guiText.text = "GET SET...";
	}
	
	else if ( timer < 3.75f) {
		guiText.transform.position.x = 0.43;
		guiText.fontSize = 80;
		guiText.material.color = Color.green;
		guiText.text = "GO!";
	}
	
	else {
		guiText.enabled = false;
		GameStartScript.levelStart = true;
		guiText.text = "";
	}
}

