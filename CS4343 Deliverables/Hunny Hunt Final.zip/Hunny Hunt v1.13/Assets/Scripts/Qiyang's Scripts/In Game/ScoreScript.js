// Script updates and display the current, goal and max blobs to players

function Update() 
{
	if(GameStartScript.hunnyCollected < GameStartScript.hunnyGoal /2 ) {
			guiText.material.color = Color.yellow;
	}
	else {
			guiText.material.color = Color.yellow;
	}
	
	guiText.text = "Current: " + GameStartScript.hunnyCollected.ToString() + "\n" + "Goal: " + GameStartScript.hunnyGoal.ToString() + "\n" + "Max: " + GameStartScript.maxHunny.ToString();
}

/*function OnMouseDown ()
{	
        current++;
}*/ 