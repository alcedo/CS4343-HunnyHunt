
function Update () {

	if(CloudTriggerScript.overCloudUI) {
		transform.localScale.x = 3;
		transform.localScale.y = 3;
		renderer.material.color= Color.yellow;
	}

	else{
		transform.localScale.x = 1;
		transform.localScale.y = 1;
		renderer.material.color= Color.white;
	}
}