// Script controls and restrict the movement of the "Save the hunny" game mechanics
// Modified for level 2

var lastMousePosition : Vector3;
var maxXPosition = 50.0;
var minXPosition = 0.0;
var onObject = false;

renderer.material.color = Color.yellow;

var checker = 0;
static var showArrow = false;
static var reachRight = false;
static var reachLeft = false;
static var playSound = false;

function OnTriggerEnter(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var vi = Camera.main.GetComponent("VerletIntegration");
		var pointMassList = vi.pointMassList;
		var constraintList = vi.constraintList;
		var phyBodyList = vi.physicsBodyList;
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
	
		checker ++;
		
		if(checker == 4) 
		{
			GameStartScript.hunnyReleased --;
			checker = 0;
			playSound = true;
			PlusOneScript.activate = true;
			Destroyer.destroyBody(pointMassList, constraintList, phyBodyList, handShakeobj.pointMass.parent);
		}
	}
}

function OnMouseOver ()
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {

	 	showArrow = true;
	}
}

function OnMouseExit ()
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {

		showArrow = false;
	}
}


function OnMouseDown ()
{	
		if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
	        onObject = true;
	    }
}

function OnMouseDrag() 
{
        if(onObject) {

            var a = Camera.main.ScreenToWorldPoint(new Vector3 (Input.mousePosition.x,Input.mousePosition.y,240));
        
        	//var pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        
       		if(a.x >= 10 && a.x <= 60) {
       		
       			transform.position.x = a.x;
       		}
        }
        
}

function OnMouseUp ()
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		onObject = false;
	}
}

function Update () 
{	
	if(onObject)
	{
		showArrow = true;
	}
	else {
		showArrow = false;
	}
	
	if(transform.position.x < 12) 
	{
       reachLeft = true;
    }
    else {
       reachLeft = false;
    }
    
    if(transform.position.x > 58) 
	{
      reachRight = true;
    }
    else 
	{
      reachRight = false;
    }
}