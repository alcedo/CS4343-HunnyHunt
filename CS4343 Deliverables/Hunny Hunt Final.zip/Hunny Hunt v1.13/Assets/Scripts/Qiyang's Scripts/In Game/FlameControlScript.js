// Script controls the flame animation in the game

var flameType = 0;

var timer:float = 0.0;

var pEmit : ParticleEmitter;


function Start() {

	pEmit = this.gameObject.GetComponent("EllipsoidParticleEmitter");
}

function Update () {
	
	timer += Time.deltaTime;
	
	if(SunSliderScript.currentNum <= 10) {
		transform.localScale.x = 0.6;
		transform.localScale.z = 0.6;
		
	}
	
	else if(SunSliderScript.currentNum <= 20) {
	
		transform.localScale.x = 0.8;
		transform.localScale.z = 0.8;
	}
	
	else if(SunSliderScript.currentNum <= 30) {
	
		transform.localScale.x = 1.2;
		transform.localScale.z = 1.2;
	}
	
	if (flameType == 0 ){
		
		if(timer%2 >= 0.1 ) {
			renderer.enabled = true;
		}
		
		else {
			renderer.enabled = false;
		}
		
		/*
		pEmit.minSize = 5.98;
		pEmit.maxSize = 5.23;
		pEmit.minEnergy = 1;
		pEmit.maxEnergy = 1;
		pEmit.worldVelocity = new Vector3(0, 3, 0);
		*/
	}
	
	else if(flameType == 1 ) {
		
		
		if(timer%2 >= 0.2 ) {
			renderer.enabled = true;
		}
		
		else {
			renderer.enabled = false;
		}
		
	/*
		pEmit.minSize = 7.23;
		pEmit.maxSize = 7.98;
		pEmit.minEnergy = 1;
		pEmit.maxEnergy = 1;
		pEmit.worldVelocity = new Vector3(0, 5.02, 0);
		*/

	}
	
	else if(flameType == 2 ){
		
		if(timer%2 >= 0.3 ) {
			renderer.enabled = true;
		}
		
		else {
			renderer.enabled = false;
		}
		
		/*
		pEmit.minSize = 9.23;
		pEmit.maxSize = 9.98;
		pEmit.minEnergy = 1;
		pEmit.maxEnergy = 1;
		pEmit.worldVelocity = new Vector3(0, 7.05, 0);
		*/
	}
}