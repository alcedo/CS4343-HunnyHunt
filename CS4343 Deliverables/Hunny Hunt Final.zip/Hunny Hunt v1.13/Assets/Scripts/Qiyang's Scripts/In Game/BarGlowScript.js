
function Update () {

	if(SunSliderScript.onObject || SunSliderScript.overObject) {
		//transform.localScale.x = 3.9;
		//transform.localScale.y = 21.1;
		renderer.material.color = Color.yellow;
	}
	
	else{
		//transform.localScale.x = 0;
		//transform.localScale.y = 0;
		renderer.material.color = Color.black;
	}
	
}