renderer.material.color = Color.yellow;

function Update () {
 
	GetComponent.<TextMesh>().text = CannonTriggerScript.currentCapacity.ToString() + "/" + CannonTriggerScript.maxCapacity.ToString();
}