// Script display a put sign near the beehive whenever a blob is saved by "save the hunny"

static var activate = false;
var timer : float = 0.0;

transform.localScale.x = 0.0;
transform.localScale.z = 0.0;

function Update () {
	
	timer += Time.deltaTime;
	
	if(activate) {
		transform.localScale.x = 1.00;
		transform.localScale.z = 0.75;
		timer = 0.0;
		activate = false;
	}
	
	if(timer <= 0.75) {
		transform.position.y += 0.1;
	}
	
	else if(timer >0.75) {
		transform.localScale.x = 0.0;
		transform.localScale.z = 0.0;
		transform.position.y = 90.0;
	}
	
	

}