renderer.material.color = Color.white;

function Update () {

	GetComponent.<TextMesh>().text = ("Hunny " + CatapultTriggerScript.currentCapacity.ToString()+ "/" + CatapultTriggerScript.maxCapacity);
}