var level = 1;

guiText.material.color = Color.cyan;

function Update() {

	guiText.text = "Level - " + level;
}

function OnMouseDown ()
{	
        //currentLevel++;
}