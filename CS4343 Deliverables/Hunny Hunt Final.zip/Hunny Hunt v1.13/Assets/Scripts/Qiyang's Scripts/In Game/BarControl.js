// Scripts controls the display of the bar meter

var barControl_00 : Texture2D;
var barControl_01 : Texture2D;
var lastMousePosition : Vector3;
var maxYPosition = 50.0;
var minYPosition = 0.0;
var onObject = false;

function OnMouseEnter ()
{
	renderer.material.mainTexture = barControl_01;
}

function OnMouseExit ()
{
	renderer.material.mainTexture = barControl_00;

}


function OnMouseDown ()
{	
        onObject = true;
}

function OnMouseDrag() 
{
        if(onObject){
		
				if(Input.mousePosition.y > lastMousePosition.y && transform.position.y <= 50) {		
					transform.position.y = Input.mousePosition.y/15;
					lastMousePosition = Input.mousePosition; 
				}
				
        }
}

function OnMouseUp ()
{
	onObject = false;
}
