// Script control transition between different scene on mouse click when player clears the stage

var stageClear = false;

function Update() {

		if(GameStartScript.hunnyCollected >= GameStartScript.hunnyGoal) {
			stageClear = true;
			renderer.enabled = true;
		}
		
		else {
			renderer.enabled = false;
		}
}

function OnMouseEnter ()
{
	transform.localScale.x = 4.2;
	transform.localScale.z = 0.6;
}

function OnMouseExit ()
{
	transform.localScale.x = 4.0;
	transform.localScale.z = 0.525;
}

function OnMouseUp ()
{
	playSound = true;
	GameStartScript.level ++;
	
	if(GameStartScript.level <=2) {
		GameStartScript.newLevel(GameStartScript.level);
	}
	
	else{
		GameStartScript.level = 1;
		FairyCrusorScript.fairyPointer = false;
		Application.LoadLevel(3);
	}
}

