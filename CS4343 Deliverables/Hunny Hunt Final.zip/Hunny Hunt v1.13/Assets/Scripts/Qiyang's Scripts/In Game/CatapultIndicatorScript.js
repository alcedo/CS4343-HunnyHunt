var indicatorOff : Texture2D;
var indicatorOn : Texture2D;

var indicatorNum = 1;

function Update () {

	if(CatapultTriggerScript.currentCapacity >= indicatorNum) {
		renderer.material.mainTexture = indicatorOn;
	}

	else{
		renderer.material.mainTexture = indicatorOff;
	}
}