// Script display in game message to players

var hunnyLeftToCollect;
static var activated = false;
static var activated_2 = false;
static var activated_3 = false;
var timer : float = 0.0;
var colorTimer : float = 0.0;


function Update() {

	hunnyLeftToCollect = GameStartScript.hunnyGoal - GameStartScript.hunnyCollected;
	timer += Time.deltaTime;
	
	if(hunnyLeftToCollect <= 10 && !activated) {
		guiText.enabled = true;
		guiText.transform.position.x = 0.70;
		guiText.material.color = Color.red;
		guiText.text = ("Collect " + hunnyLeftToCollect + " more Hunny!!!");
		activated = true;
		timer = 0.0;
	}
	
	else if (hunnyLeftToCollect <= 3 && !activated_2) {
		guiText.enabled = true;
		guiText.transform.position.x = 0.70;
		guiText.material.color = Color.red;
		guiText.text = "Collect " + hunnyLeftToCollect + " more Hunny!!!";
		activated_2 = true;
		timer = 0.0;
	}
	
	else if(hunnyLeftToCollect <= 0 && !activated_3) {
		guiText.enabled = true;
		guiText.transform.position.x = 0.70;
		guiText.material.color = Color.red;
		guiText.text = "Stage Clear! Great Job!";
		activated_3 = true;
		timer = 0.0;
	}
	
	if(timer <= 3.0) {
		colorTimer += Time.deltaTime;
		if(colorTimer <= 0.5) {
			guiText.material.color = Color.yellow;
		}
		
		else if (colorTimer <= 1.0) {
			guiText.material.color = Color.red;
		}
		
		else {
			colorTimer = 0.0;
		}
	}
	else if(timer > 3.0) {
		guiText.enabled = false;
	}
	
}

static function msgReset() {
	activated = false;
	activated_2 = false;
	activated_3 = false;
}