var potRight = true;

function OnTriggerStay(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
	
		handShakeobjA.pointMass.lockXPos(other.gameObject.transform.position.x);

		handShakeobjA.pointMass.parent.setDamping(false);
		
		if(potRight) {	
			handShakeobjA.pointMass.parent.addForce(new Vector2(-0.1, 0.0));
		}
		
		else {
			handShakeobjA.pointMass.parent.addForce(new Vector2(0.1, 0.0));
		}
	}
}	


function OnTriggerExit(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
		handShakeobjA.pointMass.unlockXPos();
		handShakeobjA.pointMass.parent.setDamping(true);
	}
}