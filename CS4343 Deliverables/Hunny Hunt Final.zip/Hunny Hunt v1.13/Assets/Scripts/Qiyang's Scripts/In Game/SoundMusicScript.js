// Script controls the in game sound effects
var inGameOptions : AudioClip;
var hunnyCollected: AudioClip;
var catapultFire: AudioClip;

function Update () {

	if(SaveHunnyScript.playSound || SaveHunnyAlternateScript.playSound) {
		gameObject.audio.clip = hunnyCollected; 
		gameObject.audio.Play();
		SaveHunnyScript.playSound = false;
		SaveHunnyAlternateScript.playSound =  false;
	}
	
	if(MenuOptionsScript.playSound) {
		gameObject.audio.clip = inGameOptions; 
		gameObject.audio.Play();
		MenuOptionsScript.playSound = false;
	}
	
	if(CatapultTriggerScript.playSound) {
		gameObject.audio.clip = catapultFire; 
		gameObject.audio.Play();
		CatapultTriggerScript.playSound = false;
	}
	
	if(MenuOptionsScript.musicOn) {
		gameObject.audio.mute = false;
	}
	
	else{
		gameObject.audio.mute = true;
	}
}