// Script controls playing and muting of backgound music

var backgroundMusic: AudioClip;

function Awake() {
	gameObject.audio.clip = backgroundMusic;
	gameObject.audio.loop = true;
	gameObject.audio.Play();
}

function Update () {

	if(MenuOptionsScript.musicOn) {
		gameObject.audio.mute = false;
	}
	
	else{
		gameObject.audio.mute = true;
	}
}