// Script controls the light intensity via the GameStartScript

static var lightValue = 0.5;

function Update () {

	light.intensity = lightValue;
	
}