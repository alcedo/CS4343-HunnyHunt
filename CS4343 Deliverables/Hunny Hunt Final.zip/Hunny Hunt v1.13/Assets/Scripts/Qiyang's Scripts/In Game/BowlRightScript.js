var bowlRight = true;
/*
function OnTriggerEnter(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
		
		handShakeobj.pointMass.lockXPos(other.gameObject.transform.position.x);
		//handShakeobj.pointMass.lockYPos(other.gameObject.transform.position.y);
		
		
		if(bowlRight == true) {
		
			handShakeobj.pointMass.addForce(new Vector2(-0.5, 0));
		}
		
		else {
			handShakeobj.pointMass.addForce(new Vector2(0.5, 0));
		}
		
	}
}
*/

function OnTriggerEnter(other : Collider)
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
		//handShakeobjA.pointMass.lockXPos(other.gameObject.transform.position.x);
		//handShakeobjA.pointMass.parent.setDamping(false);
	
		if(bowlRight) {
			handShakeobjA.pointMass.parent.addForce(new Vector2(-0.002, 0.0));
		}
		
		else {
				handShakeobjA.pointMass.parent.addForce(new Vector2(0.002, 0.0));
		}
	}
}



function OnTriggerExit(other : Collider) 
{

}
