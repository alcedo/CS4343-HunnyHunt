// Script controls the UI of the arrows when mouse over "save the hunny" object

var timer : float = 0.0;
var rightArrow = false;

function Update () {
	
	timer += Time.deltaTime;
	
	if(SaveHunnyScript.showArrow && timer%2 >= 1.0 ) {
		renderer.enabled = true;
	}
	
	else {
		renderer.enabled = false;
	}
	
	if(SaveHunnyScript.reachLeft) {
		if(rightArrow){
			renderer.enabled = false;
		}
	}
	
	if(SaveHunnyScript.reachRight) {
		if(!rightArrow){
			renderer.enabled = false;
		}
	}
}