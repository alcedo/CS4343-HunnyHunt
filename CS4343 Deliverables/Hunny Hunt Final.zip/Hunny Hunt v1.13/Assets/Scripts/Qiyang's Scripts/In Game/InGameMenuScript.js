
function Update () {

	if(GameStartScript.inGameMenu) {
		//guiTexture.pixelInset.height = 512;
		//guiTexture.pixelInset.width = 512;
		guiTexture.enabled = true;
		FairyCrusorScript.fairyPointer = false;
	}
	
	else {
		//guiTexture.pixelInset.height = 0;
		//guiTexture.pixelInset.width = 0;
		guiTexture.enabled = false;
		FairyCrusorScript.fairyPointer = true;
	}
	
	
}