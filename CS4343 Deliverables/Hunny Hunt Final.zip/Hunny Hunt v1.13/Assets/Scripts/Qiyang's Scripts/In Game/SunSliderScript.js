// Scripts controls the display of the bar meter

var bar_00 : Texture2D;
var bar_01 : Texture2D;
var bar_02 : Texture2D;
var bar_03 : Texture2D;
var bar_04 : Texture2D;
var bar_05 : Texture2D;
var bar_06 : Texture2D;
var bar_07 : Texture2D;
var bar_08 : Texture2D;
var bar_09 : Texture2D;
var bar_10 : Texture2D;
var bar_11 : Texture2D;
var bar_12 : Texture2D;
var bar_13 : Texture2D;
var bar_14 : Texture2D;
var bar_15 : Texture2D;
var bar_16 : Texture2D;
var bar_17 : Texture2D;
var bar_18 : Texture2D;
var bar_19 : Texture2D;
var bar_20 : Texture2D;
var bar_21 : Texture2D;
var bar_22 : Texture2D;
var bar_23 : Texture2D;
var bar_24 : Texture2D;
var bar_25 : Texture2D;
var bar_26 : Texture2D;
var bar_27 : Texture2D;
var bar_28 : Texture2D;
var bar_29 : Texture2D;
var bar_30 : Texture2D;

var barArray = new Array();
static var overObject = false;
static var onObject = false;
static var currentNum = 0;
private var timer : float = 0.0;

function Start () {
barArray.Push(bar_00);
barArray.Push(bar_01);
barArray.Push(bar_02);
barArray.Push(bar_03);
barArray.Push(bar_04);
barArray.Push(bar_05);
barArray.Push(bar_06);
barArray.Push(bar_07);
barArray.Push(bar_08);
barArray.Push(bar_09);
barArray.Push(bar_10);
barArray.Push(bar_11);
barArray.Push(bar_12);
barArray.Push(bar_13);
barArray.Push(bar_14);
barArray.Push(bar_15);
barArray.Push(bar_16);
barArray.Push(bar_17);
barArray.Push(bar_18);
barArray.Push(bar_19);
barArray.Push(bar_20);
barArray.Push(bar_21);
barArray.Push(bar_22);
barArray.Push(bar_23);
barArray.Push(bar_24);
barArray.Push(bar_25);
barArray.Push(bar_26);
barArray.Push(bar_27);
barArray.Push(bar_28);
barArray.Push(bar_29);
barArray.Push(bar_30);
}


function Update () {
		timer += Time.deltaTime;
		
		if(timer > 1.0 && currentNum > 0) {
		
			currentNum --;
			timer = 0.0;
		}
		
		renderer.material.mainTexture = barArray[currentNum] ;
}

function OnMouseOver ()
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		overObject = true;
		transform.localScale.x = 0.6;
		transform.localScale.z = 2.4;
	}
}

function OnMouseExit ()
{
		overObject = false;
		transform.localScale.x = 0.5;
		transform.localScale.z = 2.0;
}

function OnMouseDown ()
{	
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
        onObject = true;
    }
}

function OnMouseUp ()
{	
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
        onObject = false;
        transform.localScale.x = 0.5;
		transform.localScale.z = 2.0;
	}
}

function OnMouseDrag() 
{
        if(onObject){
        
        transform.localScale.x = 0.6;
		transform.localScale.z = 2.4;
			/*
			//transform.position.y = Input.mousePosition.y/15;
			//transform.position.y = 50;
			if(Input.mousePosition.y/14>= 0 && Input.mousePosition.y/14 <= 30.0) {
				currentNum = 	Input.mousePosition.y/14 ;
			}
			
			if(currentNum < 30) {
				currentNum += 1;
			}
			*/
			
			
			var a = Camera.main.ScreenToWorldPoint(new Vector3 (Input.mousePosition.x,Input.mousePosition.y,240));
        
        	//print(a.y);
        	if(a.y < 31) {
        		currentNum = 0;
        	} 
        	
       		if(a.y > 32 && a.y <= 52) {
       		
       			currentNum = (a.y - 30) * 1.5;
       			
       			if(currentNum < 30) {
					currentNum += 3;
				}
			
       		}
       		
       		if(currentNum > 30) {
					currentNum = 30;
				}
      
		}
}

static function sunReset() {
	currentNum = 0;
}