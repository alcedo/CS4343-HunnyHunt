//Script check for the bar meter power and apply different level of force to the blobs

var releaseLevel = 0;
var mat;

function Start() 
{
	mat = this.gameObject.GetComponent("MeshRenderer");
}

function OnTriggerStay(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		//print("OnTriggerEnter: " + other.gameObject); 
		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
		var xforce = Random.Range(0.0,1.0);
	
		if(releaseLevel == 0) {
			
			handShakeobjA.pointMass.lockYPos(other.gameObject.transform.position.y);
			//handShakeobjA.pointMass.lockXPos(other.gameObject.transform.position.x);
			
			if(xforce >= 0.5) {
			//handShakeobjA.pointMass.parent.setDamping(false);
			
				handShakeobjA.pointMass.parent.addForce(new Vector2(0.0, 0.006));
			}
			
			else {
			
				handShakeobjA.pointMass.parent.addForce(new Vector2(-0.0, 0.006));
			}
		}
		
		else if(releaseLevel == 1) {
			handShakeobjA.pointMass.parent.unlockYPos();
			//handShakeobjA.pointMass.unlockXPos();
			var num = Random.Range(0.01,0.10);
			
			if(xforce >= 0.5) {
				//handShakeobjA.pointMass.parent.setDamping(false);
				handShakeobjA.pointMass.parent.addForce(new Vector2(0.0, num));
			}
			
			else {
			
				//handShakeobjA.pointMass.parent.setDamping(false);
				handShakeobjA.pointMass.parent.addForce(new Vector2(-0.0, num));
			}
		}
		
		else if(releaseLevel == 2) {
			
			handShakeobjA.pointMass.parent.unlockYPos();
			//handShakeobjA.pointMass.unlockXPos();
			
			if(xforce >= 0.5) {
				//handShakeobjA.pointMass.parent.setDamping(false);
				handShakeobjA.pointMass.parent.addForce(new Vector2(0.0, 0.30));
			}
			
			else{
				//handShakeobjA.pointMass.parent.setDamping(false);
				handShakeobjA.pointMass.parent.addForce(new Vector2(-0.0, 0.30));
			}
			
		}
		

	}
		
		//handShakeobjA.pointMass.lockXPos(other.gameObject.transform.position.x);
		// Destroy Obj,  still has errors
		/*
		var vi = Camera.main.GetComponent("VerletIntegration");
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
		Destroyer.destroyBody(vi.pointMassList, vi.constraintList, vi.physicsBodyList, handShakeobj.pointMass.parent);
		*/
	if(other.gameObject.CompareTag("StateChange")) {
		
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager");
		
		if (releaseLevel == 0) {
		
			pm.updateEmitterState(ParticleManager.FluidState.Stationary);
		}
		
		else if (releaseLevel == 1) {
		
			pm.updateEmitterState(ParticleManager.FluidState.Stationary);
		}
		
		else if (releaseLevel == 2) {
		
			pm.updateEmitterState(ParticleManager.FluidState.Blown, new Vector2(0.0, -0.30));
		}
	}
}	


//function OnTriggerEnter(other : Collider)
//{
//	if (other.gameObject.CompareTag("Hunny"))
//	{
//		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
//		
//		if(releaseLevel == 1) {
//			handShakeobjA.pointMass.unlockYPos();
//			var num = Random.Range(0.30,0.50);
//			handShakeobjA.pointMass.addForce(new Vector2(0.0, num));
//		}
//		
//		else if(releaseLevel == 2) {
//			
//			handShakeobjA.pointMass.unlockYPos();
//			handShakeobjA.pointMass.addForce(new Vector2(0.0, 0.9f));
//			
//		}
//	}
//}

function OnTriggerExit(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
		handShakeobjA.pointMass.unlockYPos();
		//handShakeobjA.pointMass.parent.setDamping(true);
		//handShakeobjA.pointMass.unlockXPos();
	}
	
	if(other.gameObject.CompareTag("StateChange")) {
		
		var pm = other.gameObject.transform.parent.GetComponent("ParticleManager");
		pm.updateEmitterState(ParticleManager.FluidState.Falling);
	}
}

function FixedUpdate() {
	
	if(SunSliderScript.currentNum < 10) 
	{
		releaseLevel = 0;
		mat.material.SetColor("_Color", new Color(0.8196, 0.3922, 0.1961));		
	}

	else if(SunSliderScript.currentNum < 20)
	{
		releaseLevel = 1;
		mat.material.SetColor("_Color", new Color(0.7843, 0.1459, 0.0353));	
	}
	
	else if(SunSliderScript.currentNum <= 30)
	{
		releaseLevel = 2;
		mat.material.SetColor("_Color", new Color(0.90, 0.0, 0.0));	
	}
}
