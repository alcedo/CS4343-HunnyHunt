// Scripts controls the in game menu

var optionsUI = false;
var resumeUI = false;
var restartUI = false;
var mainMenuUI = false;
var helpUI = false;
static var helpOn = true;
var musicUI = false;
static var musicOn = true;

static var playSound = false;

guiText.material.color = Color.yellow;

if(helpUI || musicUI) {
	guiText.material.color = Color.green;
}	

function Update () {

	if(optionsUI) {
		guiText.material.color = Color.white;
	}
	
	if(GameStartScript.inGameMenu) {
		guiText.enabled = true;
	}
	
	else {
		guiText.enabled = false;
	}

}

function OnMouseEnter() {

	if(!optionsUI) {
		guiText.material.color = Color.red;
	}
		
}

function OnMouseExit() {

	if(!optionsUI) {
		guiText.material.color = Color.yellow;
	}
	
	if(helpUI || musicUI) {
		guiText.material.color = Color.green;
	}	
}

function OnMouseUp() {

	playSound = true;

	if(resumeUI){
		GameStartScript.resume = true;
	}

	if(restartUI){
		GameStartScript.restart = true;
	}
	
	if(mainMenuUI) {
		GameStartScript.returnToMain = true;
	}
	
	if(helpUI) {
	
		if(helpOn) {
			helpOn = false;
			guiText.text = "Help - Off"; 
		}
		
		else {
			helpOn = true; 
			guiText.text = "Help - On"; 
		}
	
	}
	
	if(musicUI) {
	
		if(musicOn) {
			musicOn = false;
			guiText.text = "Music - Off"; 
		}
		
		else {
			musicOn = true; 
			guiText.text = "Music - On"; 
		}
	
	}
	
}