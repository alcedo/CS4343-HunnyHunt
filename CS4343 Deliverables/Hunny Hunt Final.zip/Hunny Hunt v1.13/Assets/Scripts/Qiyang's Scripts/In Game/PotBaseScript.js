
function OnTriggerStay(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
	
		handShakeobjA.pointMass.lockYPos(other.gameObject.transform.position.y);

		handShakeobjA.pointMass.parent.setDamping(false);
			
		handShakeobjA.pointMass.parent.addForce(new Vector2(0.0, 0.1));
	}
}	


function OnTriggerExit(other : Collider) 
{
	if (other.gameObject.CompareTag("Hunny"))
	{
		var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");
		handShakeobjA.pointMass.unlockYPos();
		handShakeobjA.pointMass.parent.setDamping(true);
		//handShakeobjA.pointMass.unlockXPos();
	}
}