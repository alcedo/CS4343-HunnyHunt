// Script controls and restrict the movement of the "Save the hunny" game mechanics

var lastMousePosition : Vector3;
var maxXPosition = 50.0;
var minXPosition = 0.0;
var onObject = false;

renderer.material.color = Color.yellow;

var checker = 0;
static var showArrow = false;
static var reachRight = false;
static var reachLeft = false;
static var playSound = false;

function OnTriggerEnter(other : Collider) 
{
	
	//var handShakeobjA = other.gameObject.GetComponent("HandShakePointMass");

	
	
	if (other.gameObject.CompareTag("Hunny"))
	{
		var vi = Camera.main.GetComponent("VerletIntegration");
		var pointMassList = vi.pointMassList;
		var constraintList = vi.constraintList;
		var phyBodyList = vi.physicsBodyList;
		var handShakeobj = other.gameObject.GetComponent("HandShakePointMass");
	
		checker ++;
		
		if(checker == 4) {
	
			GameStartScript.hunnyReleased --;
			checker = 0;
			playSound = true;
			PlusOneScript.activate = true;
			Destroyer.destroyBody(pointMassList, constraintList, phyBodyList, handShakeobj.pointMass.parent);
		}
	}
	

}

function OnMouseOver ()
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		//renderer.material.color = Color.yellow;
		showArrow = true;
	}
}

function OnMouseExit ()
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		//renderer.material.color = Color.yellow;
		showArrow = false;
	}
}


function OnMouseDown ()
{	
		if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
	        onObject = true;
	    }
}

function OnMouseDrag() 
{
        if(onObject) {
        /*
          && transform.position.x <= 50) {
        
				if(Input.mousePosition.x != lastMousePosition.x) {
				
					transform.position.x = Input.mousePosition.x/10 - 10;
					//transform.position.y = 50;
					lastMousePosition = Input.mousePosition; 
				}
				
        }
        */

            var a = Camera.main.ScreenToWorldPoint(new Vector3 (Input.mousePosition.x,Input.mousePosition.y,240));
        
        	//var pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        
       		if(a.x >= 0 && a.x <= 120) {
       		
       			transform.position.x = a.x;
       		}
        }
        
}

function OnMouseUp ()
{
	if(!GameStartScript.inGameMenu && GameStartScript.levelStart) {
		onObject = false;
	}
}

function Update () {
	if(onObject){
		//renderer.material.color = Color.yellow;
		showArrow = true;
	}
	
	else {
		//renderer.material.color = Color.yellow;
		showArrow = false;
	}
	
	if(transform.position.x < 2) {
       reachLeft = true;
    }
       			
    else {
       reachLeft = false;
    }
    
    if(transform.position.x >118) {
      reachRight = true;
    }
       			
    else {
      reachRight = false;
    }
}