// Audio clips 
var buttonPress : AudioClip;

function Update () {

	if(NewGameScript.playSound) {
		gameObject.audio.clip = buttonPress; 
		gameObject.audio.Play();
		NewGameScript.playSound = false;
	}
		
	if(TutorialScript.playSound) {
		gameObject.audio.clip = buttonPress; 
		gameObject.audio.Play();
		TutorialScript.playSound = false;
	}
	
	if(QuitScript.playSound) {
		gameObject.audio.clip = buttonPress; 
		gameObject.audio.Play();
		QuitScript.playSound = false;
	}
	
	if(TutorialControlScript.playSound) {
		gameObject.audio.clip = buttonPress; 
		gameObject.audio.Play();
		TutorialControlScript.playSound = false;
	}
}