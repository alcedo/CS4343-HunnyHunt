var bee = false;
var bear = false;

function Update () {
	if(MainMenuControlScript.menuUI){
		if(bee) {
			transform.localScale.x = 1;
			transform.localScale.z = 1;
		}
		
		else if(bear) {
			transform.localScale.x = 0.6;
			transform.localScale.z = 0.6;
		}
	}
		
	else {
		transform.localScale.x = 0;
		transform.localScale.z = 0;
	}

}
