var nextArrow = false;
var backArrow = false;
var backToMain = false;
static var playSound = false;

function OnMouseEnter ()
{
	if((nextArrow && MainMenuControlScript.tutorialPage < MainMenuControlScript.tutorialPageMax) || (backArrow && MainMenuControlScript.tutorialPage != 0) || backToMain){
		transform.localScale.x = 0.02;
		transform.localScale.y = 0.02;
	}
	
	else {
		transform.localScale.x = 0.0;
		transform.localScale.y = 0.0;
	}
	
}

function OnMouseExit ()
{
	transform.localScale.x = 0.0;
	transform.localScale.y = 0.0;
}

function OnMouseUp ()
{
	if(nextArrow) {
		if(MainMenuControlScript.tutorialPage < MainMenuControlScript.tutorialPageMax) {
			MainMenuControlScript.tutorialPage ++;
			playSound = true;	
		} 
	}
	
	else if(backArrow) {
		if(MainMenuControlScript.tutorialPage > 0) {
			MainMenuControlScript.tutorialPage --;
			playSound = true;		
		} 
	
	}
	
	else if(backToMain) {
		MainMenuControlScript.menuUI = true;
		MainMenuControlScript.tutorialPage = 0;
		playSound = true;	
	}
}
