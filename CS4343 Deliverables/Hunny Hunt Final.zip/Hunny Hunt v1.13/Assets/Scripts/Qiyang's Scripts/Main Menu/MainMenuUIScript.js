var activateMenuUI = false;
var activateTutorialUI = false;

function Update () {
	if(MainMenuControlScript.menuUI && activateMenuUI){
		guiTexture.enabled = true;
	}
	
	else if(!MainMenuControlScript.menuUI && activateTutorialUI) {
		guiTexture.enabled = true;
	}
	
	else {
		guiTexture.enabled = false;
	}

}