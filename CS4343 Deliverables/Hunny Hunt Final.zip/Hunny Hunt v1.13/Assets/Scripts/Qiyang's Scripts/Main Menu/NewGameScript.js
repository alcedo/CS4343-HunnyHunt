var NewGame : Texture2D;
static var playSound = false;

function OnMouseEnter ()
{
	transform.localScale.x = 0.27;
	transform.localScale.y = 0.06;
}

function OnMouseExit ()
{
	transform.localScale.x = 0.25;
	transform.localScale.y = 0.05;
}

function OnMouseUp ()
{
	playSound = true;
	Application.LoadLevel(1);
}

