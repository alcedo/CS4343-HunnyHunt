guiText.material.color = Color.black;

function Update () 
{

	if(!MainMenuControlScript.menuUI){
		guiText.enabled = true;
	}
	
	else {
		guiText.enabled = false;

	}
		
	guiText.text = (MainMenuControlScript.tutorialPage + 1).ToString() + " / " + (MainMenuControlScript.tutorialPageMax + 1).ToString() ;
}