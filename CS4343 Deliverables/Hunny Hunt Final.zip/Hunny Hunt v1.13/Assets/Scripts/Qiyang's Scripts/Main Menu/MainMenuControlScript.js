var mainScreen : Texture2D;
var tutorial_0 : Texture2D;
var tutorial_1 : Texture2D;
var tutorial_2 : Texture2D;

static var menuUI = true;
var tutorialArray = new Array();
static var tutorialPage = 0;
static var tutorialPageMax = 2;

function Start () {
	tutorialArray.Push(tutorial_0);
	tutorialArray.Push(tutorial_1);
	tutorialArray.Push(tutorial_2);
}

function Update () {
	
	if(menuUI) {
		renderer.material.mainTexture = mainScreen;
	}
	
	else {
		renderer.material.mainTexture = tutorialArray[tutorialPage];
	}
}