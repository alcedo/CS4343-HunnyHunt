using UnityEngine;
using System.Collections;

public class CollisionInfo {
	
	public float Depth;
	public Vector2 Normal;
	public Constraint Edge;
	public PointMass Vertex;
	
	// default ctor
	public CollisionInfo() {
		
	}
}
