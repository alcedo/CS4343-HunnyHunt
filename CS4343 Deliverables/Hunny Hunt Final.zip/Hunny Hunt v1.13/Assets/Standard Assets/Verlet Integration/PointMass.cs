using UnityEngine;
using System.Collections;

// position in an x-y axis. 
public class PointMass {

    // Verlet integration calculation properties
    public bool movable;                	// can the particle move ?
	public bool fake = true;
//	private float dampingMax = 0.90f;		// max possible damping
//    private float damping = 0;              // damping factor used in each Step calculation

	private bool isDamped = true;			// whether to damp this pt mass
	
    public float mass = 1.0f;           	// mass always set to 1
    public Vector2 pos;                 	// current pos
    public Vector2 oldPos;              	// old pos 
    public Vector2 acceleration;        	// a vector representing the current acceleration of the particle
    public PhysicsBody parent;          	// a reference to parent container body
 
	
    // Sync-ing with Unity's Game Engine Properties
    public GameObject gameObject;           // a references to game object representation in Unity
	public bool lockXAxis = false;			// X-axis locked?
	public bool lockYAxis = false;			// Y-axis locked?
	public float lockedXPos = 0.0f;			// x pos locked to
	public float lockedYPos = 0.0f;			// y pos locked to
	public float lockThreshold = 0.03f;		// threshold for the locked position
	
	public GameObject emitPoint;
	
	// default ctor
    public PointMass() {	
		
		this.movable = true;
        this.pos = new Vector2(0.0f, 0.0f);
        this.oldPos = new Vector2(0.0f, 0.0f);
        this.acceleration = new Vector2(0.0f, 0.0f);
		//addParticleManager();
	}       
    
	public PointMass(bool mov, Vector2 pos, Vector2 oldPos, Vector2 acceleration, bool fake)
    {
        this.movable = mov;
        this.pos = pos;
        this.oldPos = oldPos;
        this.acceleration = acceleration;
		this.fake = fake;
		//addParticleManager();
		
    }
	
    public PointMass(Vector2 pos, Vector2 oldPos)
    {
        this.pos = pos;
        this.oldPos = oldPos;
		//addParticleManager();
    }
		
    public void addForce(Vector2 f)
    {	
		// acceleration = Vector2.zero;
		
		// if(acceleration.sqrMagnitude < 0.1) 
		acceleration += f / mass;
    }
	
	public bool isDamping()
	{
		return this.isDamped;	
	}
	
	public void setDamping(bool state)
	{	
		isDamped = state;
	}
	
//    public void setDamping(float dampFactor)
//    {
//        damping = dampFactor;
//    }

//    public float getDamping()
//    {
//       
//	    float oldDamping = this.damping; 
//		this.damping = this.damping + 0.01f; 
//		if(this.damping > dampingMax) {
//			// this.damping = 0.0f;
//			// UnityEngine.Debug.Log("dampMax" + dampingMax);
//			return dampingMax;
//		}
//		
//		// UnityEngine.Debug.Log("damp" + oldDamping);
//		return oldDamping;
//    }
	
//	public void addForceWithDamp(Vector2 f)
//	{
//		// if magnitude is large, damp more
//
//		float totalDamp = dampingMax/f.magnitude;
//		if(totalDamp > dampingMax) {
//			// UnityEngine.Debug.Log("above" + dampingMax/f.magnitude);
//			this.damping = 0.0f;
//		}else{
//			// UnityEngine.Debug.Log("normal" + dampingMax/f.sqrMagnitude);
//			this.damping = dampingMax - totalDamp;			
//		}
//
//		acceleration += f / mass;
//	}


	
	// Check if vector is not a number or infinity
	bool checkVectorNan(Vector2 vector) 
    {
        // || float.IsInfinity(vector.y)
		return (float.IsNaN(vector.x) || float.IsNaN(vector.y) );	
	}

    bool checkVectorInfinity(Vector2 vec)
    {
        return (float.IsInfinity(vec.x) || float.IsInfinity(vec.y));
    }
	
	private float cutFactor = 0.00f;

	public void decreaseAcceleration()
	{
		// UnityEngine.Debug.Log("SDFSDFSDSD!" + this.acceleration );
		if(this.acceleration.sqrMagnitude < 0.0001f || checkVectorNan(acceleration) ||  checkVectorInfinity(acceleration))
		{
			//UnityEngine.Debug.Log("SDFSDFSDSD!" + this.acceleration );
			this.acceleration = Vector2.zero;
			return;
		}
			
		
		cutFactor += 0.00008f;
		this.acceleration -= acceleration*(cutFactor + 0);
		
		if (fake)
			this.acceleration = Vector2.zero;	
	}
	

	
	// Lock the Y axis of the particle
	public void lockYPos(float yPos)
	{
		lockYAxis = true;
		lockedYPos = yPos;
	}
	
	// Unlock Y axis of the particle
	public void unlockYPos()
	{
		lockYAxis = false;	
	}
	
	// Lock the X axis of the particle
	public void lockXPos(float xPos)
	{
		lockXAxis = true;
		lockedXPos = xPos;
	}
	
	// Unlock X axis of the particle
	public void unlockXPos()
	{
		lockXAxis = false;	
	}
	
    public void offsetPos(Vector2 v)
    {
        if (movable) {
			
			pos += v;
		}
    }
	
	private void addParticleManager()
	{
		emitPoint = new GameObject("emitter");
		emitPoint.AddComponent("ParticleManager");
		emitPoint.transform.position = this.pos;
	}
	
	// Destroys the point mass
	public void destroyPointMass() 
	{	
		//MonoBehaviour.Destroy(emitPoint);
		MonoBehaviour.Destroy(gameObject.transform.parent.gameObject);
		
		movable = false;       
	    mass = -1.0f;           	
	    pos = new Vector2(float.NaN, float.NaN);                 
	    oldPos = new Vector2(float.NaN, float.NaN);              
	    acceleration = new Vector2(float.NaN, float.NaN);
	    parent = null;
	}
}
