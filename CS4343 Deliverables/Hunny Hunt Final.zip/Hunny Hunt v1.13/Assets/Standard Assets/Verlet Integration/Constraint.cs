using UnityEngine;
using System.Collections;

/// <summary>
/// A constraint acts both as a visual representation of an edge b/w 2 particles
/// and also serves as a real physical "Pole" between 2 PointMass.
/// </summary>
public class Constraint 
{
	// Constraint is always between 2 point masses 
    public PointMass p1;
    public PointMass p2;

    // a reference to parent container body
    public PhysicsBody parent;          

    // Length of the constraint. this is the min length b/w 2 point masses  
    public float length;

    // Some of the constraints forms the boundary of our physics body
    // while some are constraints INSIDE our physics body. those within our body we dont 
    // calculate collision.
    public bool isBoundary;

    public int spring_factor = 1;

    // give 2 numbers to generate a random number
    double perlinRandomNumber(double x, double y)
    {
        int n = (int)x + (int)y * 57;
        n = (n << 13) ^ n;
        int nn = (n * (n * n * 60493 + 19990303) + 1376312589) & 0x7fffffff;
        return 1.0 - ((double)nn / 1073741824.0);
    }

    // Returns the constraint length after multiplying by perlin noise function.
    public float getPerlinLength()
    {
        return (float)perlinRandomNumber(p1.pos.x, p2.pos.y);
    }

	// Destroys the constraint
	public void destroyConstraint() {
		
		p1 = null;
   		p2 = null;
		parent = null;
		length = -1.0f;
		isBoundary = false;
	}
}
