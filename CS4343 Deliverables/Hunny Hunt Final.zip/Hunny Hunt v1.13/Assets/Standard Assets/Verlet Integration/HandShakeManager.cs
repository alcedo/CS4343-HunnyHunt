using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Explaination:
/// This class links Unity's gameObject with our VerletIntegration Engine
/// gameObject 
/// 
/// Given a list of VerletEngine's PhysicsBody or PointMassList, this class would 
/// attach box colliders AND creating Unity's GameObjects in the unity scene 
/// for point masses in the physics body.
/// -------------------------------------------------------------------------
/// 
/// Goals:
/// External Unity Game object can detect these GameObjects entities
/// and to be able to react to it.
/// 
/// External Unity Game Object should be able to apply forces to VerletEngine's body
/// and particle using this class. 
/// 
/// VerletEngine's body should be able to apply forces and manipulate external unity's 
/// Game Object as well. 
/// 
/// ---------------------------------------------------------------------------
/// Usage: 
/// Attach this class to the game object which Verlet Integration is attached to as well
/// 
/// </summary>

// This component is REQUIRED if handshake b/w unity and verletEngine is needed.
[RequireComponent(typeof(VerletIntegration))]
public class HandShakeManager : MonoBehaviour 
{
    // This would be a direct reference to VerletEngine
    VerletIntegration verletEngine;

    private List<PointMass> pointMassList;
    private List<Constraint> constraintList;
    private List<PhysicsBody> physicsBodyList;

    bool startSync = false; 

    // Used for grouping purposes only, so we wont flood the unity obj list
    GameObject PtGroup; 

    // Create unity game objects for each particle to allow interaction
    void GenGameObjForParticles()
    {
		pointMassList = verletEngine.getPointMassList();
		GameObject PtGroup = new GameObject("Point_Mass_Group");;
		
		if (pointMassList.Count == 0)
		{
       		 Destroy(PtGroup);
		}
		
        foreach (PointMass p in pointMassList)
        {
            if (p.gameObject == null)
            {
				
                p.gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
				p.gameObject.tag = "Hunny";
                // add HandShakePointMass as a component 
                p.gameObject.AddComponent("HandShakePointMass");
                HandShakePointMass link = p.gameObject.GetComponent<HandShakePointMass>();
                link.pointMass = p;
                Collider collider = p.gameObject.GetComponent<Collider>();
                collider.isTrigger = true;

                // add Rigidbody as a component 
                p.gameObject.AddComponent<Rigidbody>();
                Rigidbody rb = p.gameObject.GetComponent<Rigidbody>();
                rb.isKinematic = true;

                p.gameObject.transform.position = p.pos;
                p.gameObject.transform.localScale = new Vector3(0.01f, 0.01f, 0.001f); // scale to be as small as possible 
                p.gameObject.transform.parent = PtGroup.transform; // parenting for organisation purposes. 
            }
        }
    }

// !!! Todo : if verlet integration were to create a new fiziks body or add new particles, WE MUST inform handshake manager !!!

    // This function is called once verletEngine has finished its start() procedure.
    void HSM_VerletStarted()
    {
        GenGameObjForParticles();
        startSync = true;
    }
    
    // Called whenever a new physics body has been added in VerletEngine
    void HSM_NewPhysicsBodyAdded()
    {
        GenGameObjForParticles();
    }
	
	// Check if vector is not a number or infinity
	bool checkVectorNan(Vector2 vector) 
    {
		return (float.IsNaN(vector.x) || float.IsNaN(vector.y) );	
	}

    bool checkVectorInfinity(Vector2 vec)
    {
        return (float.IsInfinity(vec.x) || float.IsInfinity(vec.y));
    }
    
    void SyncWithUnity()
    {
        if (startSync)
        {
            // Sync Position 
            foreach (PointMass p in pointMassList)
            {
				if (checkVectorNan(p.pos)) {
					p.pos = new Vector2(0, 0);
				} else if (checkVectorInfinity(p.pos)){
					p.pos = new Vector2(0, 0);
				}
			
                // Align and Sync Unity gameObject pos with VerletEngine particle pos
                p.gameObject.transform.position = p.pos;
            }
        }
    }

    void FixedUpdate()
    {
        SyncWithUnity();
    }

    // Use this for initialization
    void Start()
    {
        verletEngine = GetComponent<VerletIntegration>();
    }

	// Update is called once per frame
	void Update () 
    {
        
	}


}
