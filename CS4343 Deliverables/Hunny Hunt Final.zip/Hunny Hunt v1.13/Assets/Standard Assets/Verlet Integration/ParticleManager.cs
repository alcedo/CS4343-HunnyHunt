using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

// Manages the particle emitters and shape of the fluid blobs.
public class ParticleManager : MonoBehaviour {
	
	// State particle is in, default is falling
	public FluidState state;
	public List<PointMass> particle;
	public float currforceOffSetDirX = 0.0f;		// x-dir of force applied when blown, pushed.. etc.
	public float forceOffSetDirX = 0.0f;			// x-dir of force applied when blown pushed, etc.
	public float currforceOffSetDirY = 0.0f;		// y-dir of force applied to change shape when blown, pushed.. etc.
	public float forceOffSetDirY = 0.0f;			// y-dir of force applied.. when blown pushed, etc.
	
	private Vector3[] verticeList;
	private int[] triangleList;
	
	// Emitter properties
	public ParticleRenderer pRenderer;		// particle renderer component
	public ParticleAnimator pAnimator;		// particle animator component
	public ParticleEmitter pEmitter;		// particle emitter component
	
	public Material glowMat;				// particle material
	private const int MAX_PARTICLES = 8;	// max number of particles
	private const float MIN_ENERGY = 1.2f;	// min lifespan of particles
	private const float MAX_ENERGY = 1.5f; 	// max lifespan of particles
	private const float MIN_SIZE = 2.8f;	// min size of particles
	private const float MAX_SIZE = 2.9f; 	// max size of particles
	
	
	// Modifications for state parameters
	public Vector3 forceOffSetDrop = new Vector3(0.0f, 0.42f, 0.0f);
	public Vector3 forceOffSetGround = new Vector3(0.0f, 0.0f, 0.0f);
	
	public GameObject blob;
	public GameObject blobWrapper;
	public CrumpleMesh meshCrumple;
	
	// Color cycle parameters for particle animator
	 
	// Test Cycles 1
	/*
	private Color color0 = new Color(67.0f / 255.0f, 67.0f / 255.0f, 67.0f / 255.0f, 0.0f);
	private Color color1 = new Color(41.0f / 255.0f, 41.0f / 255.0f, 41.0f / 255.0f, 207.0f / 255.0f);
	private Color color2 = new Color(99.0f / 255.0f, 99.0f / 255.0f, 99.0f / 255.0f, 227.0f / 255.0f);
	private Color color3 = new Color(41.0f / 255.0f, 41.0f / 255.0f, 41.0f / 255.0f, 172.0f / 255.0f);
	private Color color4 = new Color(22.0f / 255.0f, 22.0f / 255.0f, 22.0f / 255.0f, 0.0f);
	
	*/
	
	// Test Cycles 2
	/*
	private Color color0 = new Color(254.0f / 255.0f, 229.0f / 255.0f, 172.0f / 255.0f, 0.0f);
	private Color color1 = new Color(254.0f / 255.0f, 229.0f / 255.0f, 172.0f / 255.0f, 207.0f / 255.0f);
	private Color color2 = new Color(254.0f / 255.0f, 229.0f / 255.0f, 172.0f / 255.0f, 227.0f / 255.0f);
	private Color color3 = new Color(254.0f / 255.0f, 229.0f / 255.0f, 172.0f / 255.0f, 172.0f / 255.0f);
	private Color color4 = new Color(254.0f / 255.0f, 229.0f / 255.0f, 172.0f / 255.0f, 0.0f);
	*/
	
	// Test Cycles3 
	
	private Color color0 = new Color(255.0f / 255.0f, 222.0f / 255.0f, 0f, 0f);
	private Color color1 = new Color(255.0f / 255.0f, 222.0f / 255.0f, 0f, 186.0f / 255.0f);
	private Color color2 = new Color(255.0f / 255.0f, 222.0f / 255.0f, 0f, 204.0f / 255.0f);
	private Color color3 = new Color(255.0f / 255.0f, 222.0f / 255.0f, 0f, 154.0f / 255.0f);
	private Color color4 = new Color(255.0f / 255.0f, 222.0f / 255.0f, 0f, 0f);
	
	public enum FluidState {
		
		PlatformRight, PlatformLeft, Blown, Compressed, Stationary, Falling, Lit, Drip
	};
	
	// Use this for initialization
	void Awake() {
		
		state = FluidState.Falling;
		
	}
	
	public void setParticleList(ref List<PointMass> particle)
	{	
		this.particle = particle;
		initEmitter();
	}
	
	// update state of blob
	public void updateEmitterState(FluidState state)
	{
		
		this.state = state;
	}
	
	public void updateEmitterState(FluidState state, Vector2 vec)
	{
		
		this.state = state;
		
		
		forceOffSetDirX = 0.0f;
		forceOffSetDirX = vec.x * 0.98f;
		
		forceOffSetDirY = 0.0f;
		forceOffSetDirY = vec.y * 0.98f;
	}
	
	// updates state of the blob frame by frame
	// values are tweaked via trial and error
	void FixedUpdate () {
		
		if (checkVectorNan(particle[particle.Count-1].pos)) {
        
			// do not update emitter pos
            particle[particle.Count-1].pos = new Vector2(0, 0);
		}
        
        else if (checkVectorInfinity(particle[particle.Count-1].pos)){
   
            // particle.pos = particle.oldPos;
            particle[particle.Count-1].pos = new Vector2(0, 0);
		}
		
		
		blobWrapper.transform.position = particle[particle.Count-1].pos;
		setShaderParameters();
		
		// slowly modify X,Y,Z values
		
		// Falling State
		if (state == FluidState.Falling)
		{	
			resetForceOffSet();
			pEmitter.emit = false;	
			
			if (meshCrumple.tranScaleX > 2.9f)
			{
				meshCrumple.tranScaleX -= 0.02f;
			}
		
			if (meshCrumple.tranScaleY < 5.41f)
			{
				meshCrumple.tranScaleY += 0.04f;
			}
			
			meshCrumple.localForceOffsetDir = new Vector3(currforceOffSetDirX, currforceOffSetDirY, 0.0f);
			meshCrumple.tranScaleZ = 3.1f;
		}
		
		// Compressed State
		else if (state == FluidState.Compressed)
		{
			pEmitter.emit = false;
			forceOffSetDirX = 0.1f;
			forceOffSetDirY = 0.9f;
			
			if (meshCrumple.tranScaleX < 5.0f)
			{
				meshCrumple.tranScaleX += 0.07f;
			}
			
			/*
			if (meshCrumple.tranScaleX < 3.67f)
			{
				meshCrumple.tranScaleX += 0.02f;	
			}
			*/
			
			if (meshCrumple.tranScaleY > 2.00f)
			{
				meshCrumple.tranScaleY -= 0.02f;	
			}
			
			if (currforceOffSetDirX < forceOffSetDirX)
			{
				
				currforceOffSetDirX += 0.01f;
			}
			
			if (currforceOffSetDirY < forceOffSetDirY)
			{
				
				currforceOffSetDirY += 0.025f;
			}
			
			if (currforceOffSetDirY > forceOffSetDirY && currforceOffSetDirX > forceOffSetDirX)
			{
				state = FluidState.Stationary;
			}
			
			
			meshCrumple.localForceOffsetDir = new Vector3(currforceOffSetDirX, currforceOffSetDirY, 0.0f);
			
			meshCrumple.qOffset0 = -0.25f;
			meshCrumple.qOffset1 = -0.15f;
			meshCrumple.qOffset2 = 0.15f;
			meshCrumple.qOffset3 = 0.25f;

			meshCrumple.tranScaleZ = 3.1f;
		}
		
		// Stationary State
		else if (state == FluidState.Stationary || state == FluidState.PlatformRight || state == FluidState.PlatformLeft)
		{
			resetForceOffSet();
			pEmitter.emit = false;	
			
			if (meshCrumple.tranScaleX < 3.56f)
			{
				meshCrumple.tranScaleX += 0.04f;
			}
			
			//if (meshCrumple.tranScaleX > 5.56f)
			//{
			//	meshCrumple.tranScaleX -= 0.02f;
			//}
			
			if (meshCrumple.tranScaleY > 2.33f)
			{
				meshCrumple.tranScaleY -= 0.04f;
			}
			
			meshCrumple.localForceOffsetDir = new Vector3(currforceOffSetDirX, currforceOffSetDirY, 0.0f);
			meshCrumple.tranScaleZ = 3.1f;
		}
		
		// Blown State
		else if (state == FluidState.Blown)
		{
			pEmitter.emit = false;	
			
			if (meshCrumple.tranScaleX > 2.9f)
			{
				meshCrumple.tranScaleX -= 0.02f;
			}
		
			if (meshCrumple.tranScaleY < 5.41f)
			{
				meshCrumple.tranScaleY += 0.04f;
			}
			
			if (currforceOffSetDirX < forceOffSetDirX)
			{
				
				currforceOffSetDirX += 0.01f;
			}
			
			if (currforceOffSetDirY < forceOffSetDirY)
			{
				
				currforceOffSetDirY += 0.01f;
			}
			
			if (currforceOffSetDirY > forceOffSetDirY && currforceOffSetDirX > forceOffSetDirX)
			{
				state = FluidState.Falling;
			}
			
			meshCrumple.localForceOffsetDir = new Vector3(currforceOffSetDirX, currforceOffSetDirY, 0.0f);
			
			meshCrumple.qOffset0 = 0.25f;
			meshCrumple.qOffset1 = 1.0f;
			meshCrumple.qOffset2 = 1.0f;
			meshCrumple.qOffset3 = 0.35f;
			
			meshCrumple.tranScaleZ = 3.1f;
		}
		
		
		// Drip State
		else if (state == FluidState.Drip)
		{
			pEmitter.emit = false;
			forceOffSetDirX = 0.1f;
			//forceOffSetDirY = -0.8f;
			forceOffSetDirY = -1.05f;
					
			if (meshCrumple.tranScaleX > 2.56f)
			{
				meshCrumple.tranScaleX -= 0.04f;
			}
			
			if (meshCrumple.tranScaleX < 0.56f)
			{
				meshCrumple.tranScaleX += 0.02f;
			}
			
			if (meshCrumple.tranScaleY > 2.33f)
			{
				meshCrumple.tranScaleY -= 0.04f;
			}
			
			if (currforceOffSetDirX < forceOffSetDirX)
			{
				
				currforceOffSetDirX += 0.01f;
			}
			
			if (currforceOffSetDirY > forceOffSetDirY)
			{
				
				currforceOffSetDirY -= 0.02f;
			}
			
			meshCrumple.localForceOffsetDir = new Vector3(currforceOffSetDirX, currforceOffSetDirY, 0.0f);
			
			meshCrumple.qOffset0 = 0.25f;
			meshCrumple.qOffset1 = 0.85f;
			meshCrumple.qOffset2 = 1.0f;
			meshCrumple.qOffset3 = 1.05f;
			
			//meshCrumple.qOffset0 = 0.25f;
			//meshCrumple.qOffset1 = 1.0f;
			//meshCrumple.qOffset2 = 1.0f;
			//meshCrumple.qOffset3 = 0.45f;
			
			meshCrumple.tranScaleZ = 3.1f;
		}
		
		
		// Lit State
		else if (state == FluidState.Lit)
		{
			resetForceOffSet();
			pEmitter.emit = true;	
			
			if (meshCrumple.tranScaleX < 3.56f)
			{
				meshCrumple.tranScaleX += 0.04f;
			}
			
			if (meshCrumple.tranScaleY > 2.33f)
			{
				meshCrumple.tranScaleY -= 0.04f;
			}
			
			meshCrumple.localForceOffsetDir = new Vector3(currforceOffSetDirX, currforceOffSetDirY, 0.0f);
			meshCrumple.tranScaleZ = 3.1f;		
		}
	}
	
	private void resetForceOffSet()
	{
		
		forceOffSetDirX = 0.0f;
		forceOffSetDirY = 0.0f;
	
		if (currforceOffSetDirX > 0.0f)
		{
			
			currforceOffSetDirX -= 0.01f;
		}
		
		if (currforceOffSetDirY > 0.0f)
		{
			
			currforceOffSetDirY -= 0.01f;
		}
		
		if (currforceOffSetDirY < 0.0f)
		{
			currforceOffSetDirY += 0.01f;	
		}
		
		if (meshCrumple.qOffset0 < 1.0f)
		{
			meshCrumple.qOffset0 += 0.01f;
		}
		
		if (meshCrumple.qOffset1 < 1.0f)
		{
			meshCrumple.qOffset1 += 0.01f;
		}
		
		if (meshCrumple.qOffset2 < 1.0f)
		{
			meshCrumple.qOffset2 += 0.01f;
		}
		
		if (meshCrumple.qOffset3 < 1.0f)
		{
			meshCrumple.qOffset3 += 0.01f;
		}
	}
	
	// Initialize emitter properties
	private void initEmitter() {
		
		addPrefab();
	}
	
	private void addParticleSystem(GameObject gameObj)
	{
		
		initEmitterComponent(gameObj);
		initAnimComponent(gameObj);
		initRendComponent(gameObj);	
	}
	
	// Adds mesh crumpler prefab onto blob game object
	private void addPrefab() 
	{
		blob = (GameObject) Resources.Load("Blob");
		
		setShaderParameters(); 
		
		blobWrapper = Instantiate(blob, this.gameObject.transform.position, Quaternion.identity) as GameObject;
		blobWrapper.name = "blobWrapper";
		addParticleSystem(blobWrapper);
		blobWrapper.transform.parent = this.gameObject.transform;
		
		//Camera.main.RenderWithShader(newShader, "");
		
		meshCrumple = (CrumpleMesh) blobWrapper.GetComponent("CrumpleMesh");
		//updateMesh();
	}
	
	private void updateMesh()
	{
		verticeList = new Vector3[particle.Count];
		
		for (int i = 0; i < particle.Count; i++)
		{
			
			if (i != particle.Count-1)
			{
				verticeList[i] = new Vector3(particle[i].pos.x, particle[i].pos.y, 0);
			}
			
			// offset centre vector
			else
			{
				verticeList[i] = new Vector3(particle[i].pos.x, particle[i].pos.y, 0.1f);	
			}
		}
		
		triangleList = new int[3 * (verticeList.Length-1)];
		int temp = 0;
		
		for (int i = 0; i < verticeList.Length-1; i++)
		{
			triangleList[temp] = i;
			triangleList[temp+1] = i+1;
			triangleList[temp+2] = verticeList.Length-1;
			temp++;
		}
		
		MeshFilter meshFilter = blobWrapper.GetComponent<MeshFilter>();
		Mesh mesh = meshFilter.mesh;
		mesh.Clear();
		
		mesh.vertices = verticeList;
		mesh.triangles = triangleList;
		
		mesh.RecalculateNormals();
		mesh.RecalculateBounds();
		mesh.Optimize();			
	}
	
	private void setShaderParameters() 
	{
		MeshRenderer mr = blob.GetComponent<MeshRenderer>();
		
		mr.material = (Material) Resources.Load("honeytrans");
		mr.material.shader = Shader.Find("Custom Shaders/Honey Shader");
		mr.material.SetVector("_Centroid", new Vector4(particle[particle.Count-1].pos.x, particle[particle.Count-1].pos.y, 0.0f, 1.0f));
		//mr.material.SetVector("_Centroid", new Vector4(0.0f, 0.0f, 0.0f, 1.0f));

	}
	
	// Add unity particle emitter component
	private void initEmitterComponent(GameObject gameObj) {
		
		pEmitter = (ParticleEmitter) gameObj.AddComponent("EllipsoidParticleEmitter");
		pEmitter.maxEmission = MAX_PARTICLES;
		pEmitter.minEmission = MAX_PARTICLES;
		pEmitter.minEnergy = MIN_ENERGY;
		pEmitter.maxEnergy = MAX_ENERGY;
		pEmitter.maxSize = MAX_SIZE;
		pEmitter.minSize = MIN_SIZE;
		pEmitter.emitterVelocityScale = 0.0f;
		pEmitter.worldVelocity = new Vector3(0.0f, 1.5f, 0.0f);
		pEmitter.localVelocity = Vector3.zero;
		pEmitter.rndVelocity = new Vector3(0.01f, 0.0f, 0.0f);
		pEmitter.useWorldSpace = false; // particles follow the emitter
		pEmitter.emit = false;
	}
	
	// Add unity particle animator component
	private void initAnimComponent(GameObject gameObj) {
		
		pAnimator = (ParticleAnimator) gameObj.AddComponent(typeof(ParticleAnimator));
		
		// Color cycle
		Color[] colorCycle = {color0, color1, color2, color3, color4};
		
		// animator parameters
		pAnimator.doesAnimateColor = true;	
		pAnimator.worldRotationAxis = Vector3.zero;
		pAnimator.localRotationAxis = Vector3.zero;
		pAnimator.sizeGrow = 0.02f;
		pAnimator.rndForce = new Vector3(0.5f, 0.5f, 0.5f);
		pAnimator.force	= new Vector3(0.0f, 0.0f, 0.0f);
		pAnimator.damping =	1f; 
		pAnimator.autodestruct = false;	
		pAnimator.colorAnimation = colorCycle;
	}
	
	// Add unity particle renderer component
	private void initRendComponent(GameObject gameObj) {
	
		glowMat = (Material) Resources.Load("Spark");
		
		if (glowMat == null) {
            Debug.Log("NO MAT @ initRendComponent() !!!!");
		}
		
		else {
			
			//Debug.Log("Material is...: " + glowMat);		
		}
		
		pRenderer = (ParticleRenderer) gameObj.AddComponent(typeof(ParticleRenderer));
		pRenderer.material.color = new Color(1f, 0.817f, 0.39f,1);
		pRenderer.material = glowMat;			
	}
	
	// Check if vector is not a number or infinity
	bool checkVectorNan(Vector2 vector) 
    {
        // || float.IsInfinity(vector.y)
		return (float.IsNaN(vector.x) || float.IsNaN(vector.y) );	
	}

    bool checkVectorInfinity(Vector2 vec)
    {
        return (float.IsInfinity(vec.x) || float.IsInfinity(vec.y));
    }
	
}
