using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

// Short explanation on how this verlet phyiscs system works
// -----------------------------------------------------------
// Verlet integration is based around point masses. 
// These point masses are bound together by constraints that can be rigid or flexible

// Every and any form of forces applied to a body are applied to the particles itself;
// This meant that when a PhysicsBody collides with another physics body, a response vector is calculated
// and applied to the particles directly within the physics body, instead of applying a response vector to
// the physics body.


// Short explanation of physicsBody creation process
// --------------------------------------------------
// Since the verlet physics system always deal with particles and constraint. 
// always ensure that we create these particles + constraints than record them
// down in physicsBody data structure, and register them with the PhysicsSimulator,
// ie: follow this order when adding information:
// pointMassList.add()
// constraintList.add()
// physicsBodyList.add()

/// <summary>
///  This Class is basically the name of our Physics Engine (VerletIntegration Engine) 
///  It handles all the physics related stuff. Attach this to an existing gameObject in unity 
///  for it to work 
/// </summary>


public class VerletIntegration : MonoBehaviour 
{
    // Damping forces in our physics world
    public const float GLOBAL_DAMPING = 0.1f;
	public const float FAKE_DAMPING = 0.001f;
    // How large time step each particle takes in each frame
    public const float TIME_STEP2 = 0.5f * 0.5f;

    private List<PointMass> pointMassList = new List<PointMass>();
    private List<Constraint> constraintList = new List<Constraint>();
    private List<PhysicsBody> physicsBodyList = new List<PhysicsBody>(); 

    protected CollisionInfo collisionInfo = new CollisionInfo();

    /* Gettter Functions */
    public List<PointMass> getPointMassList()
    {
        return this.pointMassList;
    }
    public List<Constraint> getConstraintList()
    {
        return this.constraintList;
    }
    public List<PhysicsBody> getPhysicsBodyList()
    {
        return this.physicsBodyList;
    }

    // The update function figures out the velocities of each point mass and 
    // moves them one step further. This is the main verlet step.
    void updatePointMasses() {
        for(int i = 0; i < pointMassList.Count; i++)
        {
            PointMass particle = pointMassList[i];

            if (particle.movable)
            {
                particleDynamics2(particle);
				
				// Only y axis locked
				if (particle.lockYAxis && !particle.lockXAxis) 
				{
					checkBorderCollision(particle, 0f, particle.lockedYPos - particle.lockThreshold, 150f, particle.lockedYPos + particle.lockThreshold);
				}
				
				// Only x axis locked
				else if (particle.lockXAxis && !particle.lockYAxis) 
				{
					checkBorderCollision(particle, particle.lockedXPos - particle.lockThreshold, 0f, particle.lockedXPos + particle.lockThreshold, 100f);
				}
				
				// Both Axis locked
				else if (particle.lockYAxis && particle.lockXAxis) 
				{
					checkBorderCollision(particle, particle.lockedXPos - particle.lockThreshold, particle.lockedYPos - particle.lockThreshold, particle.lockedXPos - particle.lockThreshold, particle.lockedYPos + particle.lockThreshold);
				}
				
				 //No axis locked
				else if (particle.fake)
				{
					particle.parent.updateEmitterState(ParticleManager.FluidState.Stationary);
					checkBorderCollision(particle, 120f, 81f, 127f, 90f);
                	
				}
				
				else
				{
					checkBorderCollision(particle, 0f, 0f, 150f, 100f);	
				}	
            } 

        }
    }
	
	// A small 'hack' that keeps the vertices inside the screen. You could of course implement static objects and create
    // four to serve as screen boundaries, but the max/min method is faster
    void checkBorderCollision(PointMass particle, float minXPos, float minYPos, float maxXPos, float maxYPos)
    {
        //if (particle.pos.y < -5) particle.pos.y = -5;  // simple ground 'collision' check. 
        //if (particle.pos.y > 10) particle.pos.y = 10;  // simple rooftop check 
		
        //if (particle.pos.x < -5) particle.pos.x = -5; // simple left right check
        //if (particle.pos.x > 5)  particle.pos.x = 5; 

        // x 0 to 150 , y 0 100
        if (particle.pos.y <= minYPos) 
		{
			particle.pos.y = minYPos;	// simple ground 'collision' check. 
        	// update to ground state
		}
		
		if (particle.pos.y >= maxYPos) particle.pos.y = maxYPos;	// simple rooftop check 

        if (particle.pos.x <= minXPos) particle.pos.x = minXPos;	// simple left right check
        if (particle.pos.x >= maxXPos) particle.pos.x = maxXPos; 

    }
    
    
    float IntervalDistance( float MinA, float MaxA, float MinB, float MaxB )
    {
	    if( MinA < MinB )
		    return MinB - MaxA;
	    else
		    return MinA - MaxB;
    }

    // Once a collision is detected, collisionInfo variable is updated
    // we could than calculate a response vector from the saved information in collisionInfo 
    bool detectCollision(PhysicsBody B1, PhysicsBody B2)
    {
        
		float MinDistance = float.MaxValue; //Initialize the length of the collision vector to a relatively large value
        
        // Iterating through all of the edges of both bodies at once
        for (int I = 0; I < B1.constraints.Count + B2.constraints.Count; I++)
        {
            Constraint E;

            if(I < B1.constraints.Count)
			    E = B1.constraints[I];      // Iterate thru Body 1 first
		    else
			    E = B2.constraints[ I - B1.constraints.Count ]; // Iterate thru Body 2

		    // Skip edge if its not a boundary edge (ie: internal edges)
		    if( !E.isBoundary) //The boundary flag has to be set manually and defaults to true
			    continue;

            // Place an axis on the edge we are currently working on
			// todo: check if axis formulae is correct... shud be y1-y2, x2-x1 ?
            Vector2 Axis = new Vector2(E.p1.pos.y - E.p2.pos.y , E.p2.pos.x - E.p1.pos.x);
            Axis.Normalize();

            // Project both bodies onto the perpendicular to the given axis
            float MinA, MinB, MaxA, MaxB;
            B1.ProjectToAxis(Axis, out MinA, out MaxA);
            B2.ProjectToAxis(Axis, out MinB, out MaxB);
 
            // Calculate the distance between the two projected intervals
		    float Distance = IntervalDistance( MinA, MaxA, MinB, MaxB ); 

		    if( Distance > 0.0f ) {// If the intervals don't overlap, return, since there is no collision
				
				return false;
			
			}else if(  Math.Abs( Distance ) < MinDistance ) {
			    MinDistance = Math.Abs( Distance );

                collisionInfo.Normal = Axis;    // Save collision information for later
                collisionInfo.Edge = E;         // Store the edge, as it is the collision edge

		    }
        }

        //////////////////////  The following code deals with collision RESPONSE ////////////////////////
        collisionInfo.Depth = MinDistance;

		
        // We always set collision edge to be in B1
        // and collision vertex to be in B2 by our own convention to prevent confusion
        // over which body should we "push" away in the response vector  
        if (collisionInfo.Edge.parent != B2)
        { 
            PhysicsBody Temp = B2;
            B2 = B1;
            B1 = Temp;
        }

        // This is needed to make sure that the collision normal is pointing at B1. 
        int Sign = (int) Mathf.Sign( Vector2.Dot(collisionInfo.Normal , (B1.center - B2.center)) ); 

       
        // the normal N is given by the collision normal
        if (Sign != 1) //if not +ve 
            collisionInfo.Normal = -collisionInfo.Normal; // Revert the collision normal if it points away from B1

        // this is to get the smallest distance. 
        float SmallestD = float.MaxValue;               
        for (int I = 0; I < B1.particle.Count; I++)
        {
            // Remember that the line equation is N*(R - R0 ). We choose B2->Center as R0; 
            float Distance = Vector2.Dot (collisionInfo.Normal , (B1.particle[I].pos - B2.center)); //Measure the distance of the vertex from the line using the line equation
                
            if (Distance < SmallestD)
            {   // If the measured distance is smaller than the smallest distance reported so far, set the smallest distance and the collision vertex
                SmallestD = Distance;
                collisionInfo.Vertex = B1.particle[I];
            }
        }

        return true; //There is no separating axis. Report a collision!
    }

    // This function is called every update(); 
    void processCollision()
    {
        PointMass E1 = collisionInfo.Edge.p1;
        PointMass E2 = collisionInfo.Edge.p2;

        Vector2 CollisionVector = collisionInfo.Normal * collisionInfo.Depth;

        float T;
        if (Math.Abs(E1.pos.x - E2.pos.x) > Math.Abs((E1.pos.y - E2.pos.y)))
            T = (collisionInfo.Vertex.pos.x - CollisionVector.x - E1.pos.x) / (E2.pos.x - E1.pos.x);
        else
            T = (collisionInfo.Vertex.pos.y - CollisionVector.y - E1.pos.y) / (E2.pos.y - E1.pos.y);

        float Lambda = 1.0f / (T * T + (1 - T) * (1 - T));

        E1.pos -= CollisionVector * (1 - T) * 0.5f * Lambda;
        E2.pos -= CollisionVector * T * 0.5f * Lambda;

        collisionInfo.Vertex.pos += CollisionVector * 0.5f;
    }

    // This function calculates based on vectors, along with accelerations and damping motions. 
    void particleDynamics2(PointMass particle)
    {
  		Vector2 gravityConstant = new Vector2(0.000f, -0.20f) / particle.mass;
		
		// Find delta velocity, original pos - old pos
        Vector2 dVelocity = particle.pos - particle.oldPos;

        // Record current pos as old pos b4 updating
        particle.oldPos = particle.pos;

        // adding random forces to the particles...
        // particle.addForce(new Vector2(0.000f, -0.01f));

        // Factor in velocity (add in other forces like damping and acceleration if you want here) 
        // particle.pos = particle.pos + dVelocity * (1.0f - DAMPING) + particle.acceleration;
		
		if(particle.isDamping() && !particle.fake)
		{
			float total_damping = GLOBAL_DAMPING ;
        	particle.pos = particle.pos + dVelocity * total_damping + (particle.acceleration + gravityConstant);
		}
		else if(particle.isDamping() && particle.fake)
		{
			particle.addForce(new Vector2(0.000f, -0.01f));
			
			float total_damping = FAKE_DAMPING ;
        	particle.pos = particle.pos + dVelocity * (1.0f - total_damping) + particle.acceleration;
		}
		else
		{
			particle.pos = particle.pos + dVelocity + particle.acceleration;
		}
		
		if (checkVectorNan(particle.pos)) {
        
			// do not update emitter pos
            particle.pos = new Vector2(0, 0);
		}
        
        else if (checkVectorInfinity(particle.pos)){
   
            // particle.pos = particle.oldPos;
            particle.pos = new Vector2(0, 0);
		}

		//particle.emitPoint.transform.position = particle.oldPos;
		// particle.acceleration = Vector2.zero;  // resets to 0 because factored into pos - old pos calculations. 
		particle.decreaseAcceleration();
    }
    
	// Check if vector is not a number or infinity
	bool checkVectorNan(Vector2 vector) 
    {
        // || float.IsInfinity(vector.y)
		return (float.IsNaN(vector.x) || float.IsNaN(vector.y) );	
	}

    bool checkVectorInfinity(Vector2 vec)
    {
        return (float.IsInfinity(vec.x) || float.IsInfinity(vec.y));
    }
    // This function calculates based on adding numbers to x / y component of the particles
    void particleDynamics1(PointMass particle)
    {
        // Find delta velocity, original pos - old pos
        Vector2 dVelocity = particle.pos - particle.oldPos;

        // Add some gravity forces
        dVelocity.y = dVelocity.y - 0.010f;

        // Add some random forces
        dVelocity += new Vector2(0.0011f / 2.0f, 0.003f);

        // Record current pos as old pos b4 updating
        particle.oldPos = particle.pos;

        // Factor in velocity (add in other forces like damping and acceleration if you want here) 
        particle.pos = particle.pos + dVelocity;

	}
    
	// Apply attractive forces amongst particles
    void interBodyAttractions()
    {
        float attractionForce = 0.0005f;
        List<PhysicsBody> done = new List<PhysicsBody>();

        for (int i = 0; i < physicsBodyList.Count; i++)
        {
            if (done.Count != 0)
            {
                foreach (PhysicsBody p in done)
                {
                    // ensure that pt[i] hasn't been processed already
                    if (p == physicsBodyList[i])
                        continue;
                }
            }

            // If pt[i] hasn't been processed alr, compare this with the neighboring body. 
            foreach (PhysicsBody neighbor in physicsBodyList)
            {
                if (physicsBodyList[i] != neighbor) // Make sure we are not dealing with the same body
                {
                    // Check distance b.w body and neighbor. 
                    Vector2 distVector = neighbor.center - physicsBodyList[i].center;

                    // Only apply small force force if they are near enough to one another 
                    if (distVector.magnitude < 4.0f)
                    {
                        physicsBodyList[i].addForce(distVector.normalized * attractionForce);
                        neighbor.addForce(-distVector.normalized * attractionForce);
                    }

                }
            }

        }

    }
	
    // Simple bounding box overlapping test. If overlap than calculate an accurate one 
    bool checkBodiesOverlap( PhysicsBody B1, PhysicsBody B2 ) 
    { 
	    return ( B1.MinX <= B2.MaxX ) && ( B1.MinY <= B2.MaxY ) && ( B1.MaxX >= B2.MinX ) && ( B2.MaxY >= B1.MinY );
    }

    // Cycle thru each body checking for collision
    void iterateCollision()
    {
        int Iterations = 5; // more iterations == increase accuracy 
        for (int I = 0; I < Iterations; I++)
        {
            // Rmb to update constraints first ?
            foreach (PhysicsBody body in physicsBodyList)
            {
                body.CalculateCenter(); //Recalculate the center and set bounding box value

                if (checkVectorNan(body.center))
                {
                    // do not update emitter pos
                    body.center = new Vector2(0, 0);
                }

                else if (checkVectorInfinity(body.center))
                {
                    // particle.pos = particle.oldPos;
                    body.center = new Vector2(0, 0);
                }

                body.emitter.transform.position = body.center; //update emitter position
            }

            for (int B1 = 0; B1 < physicsBodyList.Count; B1++)
            { //Iterate trough all bodies
                for (int B2 = 0; B2 < physicsBodyList.Count; B2++)
                {
                    if (B1 != B2)
                        if (checkBodiesOverlap(physicsBodyList[B1], physicsBodyList[B2])) //Test the bounding boxes
                            if (detectCollision(physicsBodyList[B1], physicsBodyList[B2])) //If there is a collision, respond to it
                                processCollision();
                }
            }
        }
    }

    // used to add constraints b/w particles. The constraint would always ensure that the particles are 
    // kept at a constant distance apart throughout.
    void updateConstraints()
    {
        int MAX_CONSTRAINT_ITERATON = 5; // more iteration is rigid, less is soft.
        for (int i = 0; i < MAX_CONSTRAINT_ITERATON; i++)
        {
            foreach (Constraint c in constraintList)
            {
                float dist = Vector2.Distance(c.p1.pos, c.p2.pos); //simple dist formulae
                float diff = dist - c.length; // shows margin of error, so that we can correct it
                Vector2 dxy = c.p1.pos - c.p2.pos;    //differences b/w x's and y's

                if (c.length > 0)
                    diff = diff / c.length;
                else
                    diff = 0;

                dxy = dxy * 0.5f; // squishy factor.

                //Push both vertices apart by half of the difference respectively 
                //so the distance between them equals the original length
                //Note: Apply changes only if the point masses are movable 
                if(c.p1.movable) c.p1.pos = c.p1.pos - (diff * dxy);
                if(c.p2.movable) c.p2.pos = c.p2.pos + (diff * dxy);
            }
        }
    
    }


    /*  Drawing functions */
    void drawConstraints()
    {
        foreach (Constraint c in constraintList)
        {
            Debug.DrawLine(c.p1.pos, c.p2.pos, Color.blue);
        }
    }

    // short cut function to create a sphere.
    void drawParticle()
    {
        foreach (PointMass p in pointMassList)
        {
            Debug.DrawLine(p.pos, new Vector2(p.pos.x + 0.1f, p.pos.y + 0.01f), Color.red);
        }

    }


    /// <summary>
    /// Create a point mass and add it into VerletIntegration Engine
    /// </summary>
    /// <param name="coordinates"> Starting x-y location to be created at </param>
    /// <param name="velocity"> Give this particle a starting velocity </param>
    PointMass createPointMass(bool mov, Vector2 position, Vector2 velocity, bool fake)
    {
     	
		Vector2 oldPos = position - velocity;
		Vector2 acceleration = Vector2.zero;
        PointMass pointMass = new PointMass(mov, position, oldPos, acceleration, fake);
        pointMassList.Add(pointMass);

        return pointMass;
    }
	
	// Destroy physics body in physics body list
	// Cheating method to remove physics body
	void destroyBody(int body) {
		
		Destroyer.destroyBody(ref pointMassList, ref constraintList, ref physicsBodyList, body);
	}

    /// <summary>
    /// Create a constraint b/w 2 particles and add it into VerletIntegration Engine
    /// </summary>
    Constraint createConstraint(PointMass p1, PointMass p2, bool boundary)
    {
        Constraint c = new Constraint();
        c.p1 = p1;
        c.p2 = p2;
		c.isBoundary = boundary;
        c.length = Vector2.Distance(c.p1.pos, c.p2.pos);
        constraintList.Add(c);

        return c;
    }

    void FixedUpdate()
    {
        updatePointMasses();
        updateConstraints();
		
		interBodyAttractions();
		
        iterateCollision();
        
		drawParticle();
        drawConstraints();
    }
	
	// convert degrees to radians
	float D2R(float angle)
	{
		 return (angle / 180 )	* Mathf.PI;
	}
		
	// Create a circular physics body at x,y pos location. N represents amt of triangles representing this body. 
	void createCircularPhysicBody(float x, float y, float radius, int n, bool fake)
	{

		float rotationAngle = D2R(360) / n; 	
		List<Vector2> ptsLocation = new List<Vector2>();

		// Rotate about a point
		for (int i = 0; i < n; i++) 
		{
			ptsLocation.Add(new Vector2(radius*Mathf.Cos(rotationAngle*i) + x , radius*Mathf.Sin(rotationAngle*i) + y));
		}
		
	
		List<PointMass> vertex = new List<PointMass>();
		List<Constraint> edges = new List<Constraint>();
		Vector2 center = Vector2.zero; 
		
		// Start creating particles at calculated positions. 
		foreach ( Vector2 loc in ptsLocation )
		{
			PointMass p = createPointMass(true, loc, new Vector2(0.0f, 0.0f), fake);
			vertex.Add(p);
			center += loc;
		}
		center /= ptsLocation.Count;
		
		// create central particle. 
		PointMass centralPt = createPointMass(true, new Vector2(x,y), new Vector2(0.0f, 0.0f), fake);
		
		// link all particles up with constraints. 
		for(int i = 0; i < vertex.Count; i ++)
		{
			if(i != vertex.Count -1){
				Constraint externalConstraint = createConstraint(vertex[i],vertex[i+1], true);
				edges.Add(externalConstraint);
			}else{
				Constraint externalConstraint = createConstraint(vertex[0],vertex[vertex.Count-1], true);
				edges.Add(externalConstraint);
			}
			
			
	
			if((i % 2 == 1)) // odd number
			{ 
				if(i+2 < vertex.Count){
					Constraint internalConstraint = createConstraint(vertex[i], vertex[i+2], false);
					edges.Add(internalConstraint);
				}else {
		
					Constraint internalConstraint = createConstraint(vertex[i+2 - vertex.Count], vertex[i], false);
					edges.Add(internalConstraint);
				
				}
				
			}
			
				
			if((i % 2 == 0)) // even number
			{ 
				if(i+2 < vertex.Count){
					Constraint internalConstraint = createConstraint(vertex[i], vertex[i+2], false);
					edges.Add(internalConstraint);
				}else {
		
					Constraint internalConstraint = createConstraint(vertex[i+2 - vertex.Count], vertex[i], false);
					edges.Add(internalConstraint);
				
				}
				
			}
			
			Constraint internalConstraint2 = createConstraint(centralPt, vertex[i], false);
			edges.Add(internalConstraint2);
		}
		
		vertex.Add(centralPt);
		
		PhysicsBody pBody = new PhysicsBody(ref vertex, ref edges);
		physicsBodyList.Add(pBody);	
				
	}
	
	void createTestPlank()
	{
		 
// 		this.createSquarePhysicsBody(1,1,50.0f,2.0f);
//		List<PointMass> vertextest = new List<PointMass>();
//		List<Constraint> edgestest = new List<Constraint>();
//		
//		PointMass testP1 = createPointMass(true, new Vector2(2,2) , new Vector2(0.0f, 0.0f));
//		PointMass testP2 = createPointMass(true, new Vector2(70,2) , new Vector2(0.0f, 0.0f));
//		vertextest.Add(testP1);
//		vertextest.Add(testP2);
//	
//		Constraint testConstraint = createConstraint(testP1, testP2, true);
//		edgestest.Add(testConstraint);
//		
//		PhysicsBody testbody = new PhysicsBody(ref vertextest, ref edgestest);
//		physicsBodyList.Add(testbody);			
		
	
	}
	
	// Create a squarePhysics body, numEntity refers to amount of squares Squared within 1 square body.
	void createSquarePhysicsBody(float x, float y, float width, float height, int numEntity)
	{
		float smallRowLength = width / numEntity;
		float smallColLength = height / numEntity;
		
		List<PointMass> vertex = new List<PointMass>();
		List<Constraint> edges = new List<Constraint>();
		
		// create pt Mass mesh first
		for(int i = 0; i < numEntity; i++)
			for(int j = 0; j < numEntity; j++)
		{

			PointMass p = createPointMass(true, new Vector2(x + (j*smallRowLength), y+(i*smallColLength)), new Vector2(0.0f, 0.0f), true);
			vertex.Add(p);

		}
		
		// place all horizontal constraints
		for(int i = 0; i < numEntity; i++)
			for(int j = 0; j < numEntity; j++)
		{
			if(j != numEntity-1){
				Constraint c = createConstraint(vertex[j+(i*numEntity)], vertex[j+(i*numEntity) + 1], true);
				edges.Add(c);
			}
				
		}
		
		// place place all vertical constraints
		for(int i = 0; i < numEntity; i++)
			for(int j = 0; j < numEntity; j++)
		{
			if(j != numEntity-1){
				Constraint c = createConstraint(vertex[i+(j*numEntity)], vertex[i+(j*numEntity)+ numEntity], true);
				edges.Add(c);
			}
				
		}
		
		
		for(int i = 0; i<numEntity-1; i++)
			for(int j = 0; j<numEntity-1; j++)
		{
			int indexPt = j+ i*numEntity;
			
			Constraint c = createConstraint(vertex[indexPt] , vertex[indexPt+ numEntity+1],  false); 
			edges.Add(c);
			 c = createConstraint(vertex[indexPt+1] , vertex[indexPt + numEntity],  false); 
			edges.Add(c);
		}
				
		

		
		PhysicsBody pBody = new PhysicsBody(ref vertex, ref edges);
		physicsBodyList.Add(pBody);	
	}
	
    // Try to only create a bodies via a function, to ensure proper registration etc 
	// Createa a square physics body, at position X , Y, with specific width and height

// todo: its either we use the physics engine to create a box, or we use physicsBody.create
// and add a World.Add(PhysicsBody) function 
    void createSquarePhysicsBody(float x, float y, float width, float height, bool fake)
    {
		// create the vertex
		PointMass p1 = createPointMass(true, new Vector2(x, y), new Vector2(0.0f, 0.0f), fake);
        PointMass p2 = createPointMass(true, new Vector2(x + width, y), new Vector2(0.0f, 0.0f), fake);
        PointMass p3 = createPointMass(true, new Vector2(x + width, y + height), new Vector2(0.0f, 0.0f), fake);
        PointMass p4 = createPointMass(true, new Vector2(x, y + height), new Vector2(0.0f, 0.0f), fake);
        
        // Square box. rmb to set boundary condition, else physics sim would fail
        Constraint c1 = createConstraint(p1, p2, true);
        Constraint c2 = createConstraint(p2, p3, true);
        Constraint c3 = createConstraint(p3, p4, true);
        Constraint c4 = createConstraint(p1, p4, true);
		
		// side ways. 
        Constraint c5 = createConstraint(p1, p3, false); 
        Constraint c6 = createConstraint(p2, p4, false); 
		
		List<PointMass> vertex = new List<PointMass>();
		vertex.Add(p1);
		vertex.Add(p2);
		vertex.Add(p3);
		vertex.Add(p4); 
		
		List<Constraint> edges = new List<Constraint>();
		edges.Add(c1);
		edges.Add(c2);
		edges.Add(c3);
		edges.Add(c4);
		edges.Add(c5);
		edges.Add(c6);
		
		PhysicsBody pBody = new PhysicsBody(ref vertex, ref edges);
		physicsBodyList.Add(pBody);	
	}
	

	// Use this for initialization
	void Start () {
 		createTestPlank();
        // Informs every other MonoBehaviour in this game object.
        this.SendMessage("HSM_VerletStarted");
	}
	
	// Apple a force to EVERY SINGLE POINTMASS in our list
    void applyForce() {
		foreach (PointMass pMass in pointMassList) {
			float randScalar = (UnityEngine.Random.Range(0.1f, 0.7f)); 
			pMass.addForce(Vector2.up * randScalar);
		}
	}

    public void addBodyOnMouseClick(float xPos, float yPos, int sides, bool fake)
    {
        // this.createSquarePhysicsBody(xPos, yPos, 3.0f, 3.0f, 4);
		if (fake)
		{
			this.createSquarePhysicsBody(xPos, yPos, 1.0f, 1.0f, fake);
		}
		
		else
		{
			this.createCircularPhysicBody(xPos, yPos, 1.5f, sides, fake);
		}
		
        this.SendMessage("HSM_NewPhysicsBodyAdded");
    }

	// Update is called once per frame
	void Update () 
    {
        bool mouseInput = false;

        if (mouseInput)
        {
            // Spacebar
            if (Input.GetButtonDown("Jump"))
            {

                print("Force Applied!");
                applyForce();
            }

            // Ctrl Button 
            if (Input.GetButtonDown("Fire1"))
            {
                print("Add body!");
                addBodyOnMouseClick(3.0f, 3.0f, 5, true);
            }

            // Left Alt
            if (Input.GetButtonDown("Fire2"))
            {

                int number = UnityEngine.Random.Range(0, physicsBodyList.Count);
                print("Destroy body " + number + "!");
                destroyBody(number);
            }

        }

	}
}

