using UnityEngine;
using System.Collections;

public class ApplyForceInteraction : MonoBehaviour , InteractionManager {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public int getInteraction(HandShakePointMass pt)
	{
	
			return 0;
	}
	
}
