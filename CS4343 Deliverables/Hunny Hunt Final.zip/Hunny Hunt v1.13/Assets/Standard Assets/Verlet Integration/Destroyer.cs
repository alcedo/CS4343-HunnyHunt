using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

// Destroyer class used to destroy physics body objects, point masses, constraints.
public class Destroyer
{
	static List<PointMass> pointMassToDel = new List<PointMass>();
	static List<Constraint> constraintToDel = new List<Constraint>();
	
	public Destroyer()
	{
		
	}
	
	// For use in C# files
	public static void destroyBody(ref List<PointMass> particles, ref List<Constraint> constraints, ref List<PhysicsBody> physicsBodies, int bodyIndex)
	{
		
		PhysicsBody tempBody = null;
		int i = 0;
		
		// finding the physics body to remove
		foreach (PhysicsBody p in physicsBodies) {
			
			if (i == bodyIndex) {
				
				tempBody = p;
			}
			
			else {
				
				i++;
			}
		}
		
		destroyPointMass(ref particles, ref tempBody);
		destroyConstraints(ref constraints, ref tempBody);
		
		if (tempBody != null) {
			tempBody.destroyBody();
			physicsBodies.Remove(tempBody);
		}
		
		resetLists();
	}
	
	// For use in .js files
	public static void destroyBody(List<PointMass> particles, List<Constraint> constraints, List<PhysicsBody> physicsBodies, PhysicsBody body)
	{
		
		PhysicsBody tempBody = body;
		
		destroyPointMass(ref particles, ref tempBody);
		destroyConstraints(ref constraints, ref tempBody);
		
		if (tempBody != null) {
			tempBody.destroyBody();
			physicsBodies.Remove(tempBody);
		}
		
		resetLists();
	}
	
	// Resets lists in destroyer class for future use
	private static void resetLists()
	{
		pointMassToDel.Clear();
		constraintToDel.Clear();
	}
	
	// Removes point mass from list of point masses
	public static void destroyPointMass(ref List<PointMass> particles, ref PhysicsBody body)
	{
		
		foreach (PointMass pMass in particles) 
		{
			
			if (body != null && pMass.parent == body) {
				
				pMass.destroyPointMass();
				pointMassToDel.Add(pMass);
			}
		}
		
		foreach (PointMass pMass in pointMassToDel) 
		{	
			particles.Remove(pMass);
			pMass.destroyPointMass();
		}
	}
	
	// Removes constraints from list of constraints
	public static void destroyConstraints(ref List<Constraint> constraints, ref PhysicsBody body)
	{
		foreach (Constraint c in constraints) 
		{
			if (body != null && c.parent == body) 
			{
				constraintToDel.Add(c);
			}
		}
		
		foreach (Constraint c in constraintToDel) 
		{	
			constraints.Remove(c);
			c.destroyConstraint();
		}	
	}
}

