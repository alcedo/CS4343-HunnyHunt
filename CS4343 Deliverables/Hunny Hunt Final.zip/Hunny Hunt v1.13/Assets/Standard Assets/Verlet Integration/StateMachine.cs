using UnityEngine;
using System.Collections;

// State Manager
public class StateMachine {
	

}
