using UnityEngine;
using System.Collections;

interface InteractionManager
{

     int getInteraction(HandShakePointMass point);
}
