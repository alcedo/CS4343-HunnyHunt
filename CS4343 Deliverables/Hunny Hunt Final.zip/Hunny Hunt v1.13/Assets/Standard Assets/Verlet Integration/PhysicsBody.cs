using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

/// <summary>
/// A physics body is simply a data structure to record which 
/// grp of particles are supposed to be grouped together. 
/// 
/// The physics engine would use these "grouped" information to calculate
/// the appropriate collision information to be APPLIED to each particles
/// in the physics engine. 
/// 
/// </summary>
public class PhysicsBody {

    /* Variables for Representations  */

    // particles are basically vertex for our physics body
    public List<PointMass> particle;     
    // constraints are basically edges for our physics body
    public List<Constraint> constraints; 
   
	// to represent this object in unity.
    public GameObject emitter;
	
    /* Variables for calculating collision */
    
    public Vector2 center; //Center of mass
 

	public int MinX, MinY, MaxX, MaxY; // Min / Max coordinates of the bounding box

    /*
     * This function would project a 1D line, perpendicular to the seperating axis 
     * than calculate the min / max variable to be used in calculating whether 
     * 2 physics body would collide 
     */ 
    public void ProjectToAxis(Vector2 Axis, out float Min, out float Max )
    {
        float DotP = Vector2.Dot(Axis, particle[0].pos);
      
        //Set the minimum and maximum values to the projection of the first vertex
        Min = Max = DotP;

        for (int I = 1; I < particle.Count; I++)
        {
            //Project the rest of the vertices onto the axis and extend 
            //the interval to the left/right if necessary
            DotP = Vector2.Dot(Axis , particle[I].pos);

            Min = Math.Min(DotP, Min);
            Max = Math.Max(DotP, Max);
        }


    }

//    public void SetBodyDamping(float dampFactor)
//    {
//        foreach (PointMass p in particle)
//        {
//            p.setDamping(dampFactor);
//        }
//    }
    	
    // Calculates the venter of mass
    public void CalculateCenter()
    {
        center = Vector2.zero; 

        MinX = MinY = (int)10000.0f;
        MaxX = MaxY = (int)-10000.0f;

        for (int I = 0; I < particle.Count; I++)
        {
            center += particle[I].pos;

            MinX = (int)Math.Min(MinX, particle[I].pos.x);
            MinY = (int)Math.Min(MinY, particle[I].pos.y);
            MaxX = (int)Math.Max(MaxX, particle[I].pos.x);
            MaxY = (int)Math.Max(MaxY, particle[I].pos.y);
        }

        center /= particle.Count;
    }

    public PhysicsBody() { } // default ctor. 

    // Create a physics body, given a list of particles and coressponding constraints
    // Between each particle. 
    public PhysicsBody(ref List<PointMass> particles, ref List<Constraint> constraints)
    {
        this.particle = particles;
        this.constraints = constraints;
		
		/*
		meshRenderer = (MeshRenderer) gameObject.AddComponent(typeof(MeshRenderer));
		meshRenderer.material = (Material) Resources.Load("Spark");
		
		meshFilter = (MeshFilter) gameObject.AddComponent(typeof(MeshFilter));
		gameObject.AddComponent("MCBlob");
		*/
		
        /* These are compulsory calc to be invoked to ensure that collision detection works */
        foreach (PointMass p in particle)         // Set parent handler. 
		{
			p.parent = this;
			//p.emitter.transform.parent = gameObject.transform;
		}
		
        foreach (Constraint c in constraints)      
		{
			c.parent = this;
		}
		
        this.CalculateCenter();
		addParticleManager();
    }
	
	public void updateEmitterState(ParticleManager.FluidState state)
	{
		
		ParticleManager pm = emitter.GetComponent<ParticleManager>();
		pm.state = state;
	}
	
	public void addForce(Vector2 f)
    {	
		foreach (PointMass pMass in particle)
		{
			pMass.addForce(f);
		}
	}
	
	public void unlockYPos()
    {	
		foreach (PointMass pMass in particle)
		{
			pMass.unlockYPos();
		}
	}
	
	public void setDamping(bool state)
    {	
		foreach (PointMass pMass in particle)
		{
			pMass.setDamping(state);
		}
	}
	
	// Adds Particle manager to gameobject
	private void addParticleManager()
	{
		emitter = new GameObject("emitter");
		emitter.AddComponent("ParticleManager");
		
		ParticleManager pm = emitter.GetComponent<ParticleManager>();
		pm.setParticleList(ref particle);
		emitter.transform.position = this.center;
	}
	
	// destroys this physics body
	public void destroyBody() 
	{
		MonoBehaviour.Destroy(emitter);
		particle.Clear();
		constraints.Clear();
		
		center = new Vector2(float.NaN, float.NaN);
 		MinX = int.MinValue;
		MinY = int.MinValue;
		MaxX = int.MinValue;
		MaxY = int.MinValue;
	}
}
