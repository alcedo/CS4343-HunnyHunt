using UnityEngine;
using System.Collections;

public class TestCollide : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerEnter(Collider other)
    {
        print("TRIGGGGGGGGGGGER !");
    }

	
    void OnCollisionEnter(Collision collision)
    {
        
		

		
		print("COLLLLLLIDED sia!");
    }
	
	void OnCollisionStay(Collision collisionInfo) {
		foreach (ContactPoint contact in collisionInfo.contacts) {
            Debug.DrawRay(contact.point, contact.normal, Color.white);
        }
		print("collide stay");
	}
}
