// Taken from Unity's Procedural Package
// Modified speed and scale values
// This script is placed in public domain. The author takes no responsibility for any possible harm.
using UnityEngine;
using System.Collections;

public class CrumpleMesh : MonoBehaviour {
	
	public float tranScaleX = 3.1f;
	public float tranScaleY = 3.1f;
	public float tranScaleZ = 3.1f;
	
	public Vector3 localForceOffsetDir = Vector3.zero;
	public Vector3 localForceOffsetDir0 = Vector3.zero;
	public Vector3 localForceOffsetDir1 = Vector3.zero;
	public Vector3 localForceOffsetDir2 = Vector3.zero;
	public Vector3 localForceOffsetDir3 = Vector3.zero;
	
	public float qOffset0 = 0.0f;
	public float qOffset1 = 0.0f;
	public float qOffset2 = 0.0f;
	public float qOffset3 = 0.0f;
	
	public float forceOffSetMag = 0.0f;
	
	public float meshScaleX = 0.3f;
	public float meshScaleY = 0.3f;
	public float meshScaleZ = 0.3f;
	public float speed = 0.2f;
	public bool recalculateNormals = true;
	
	public float xOffset = 0.1365143f;
	public float yOffset = 1.21688f;
	public float zOffset = 2.5564f;
	
	private Vector3[] baseVertices;
	private Perlin noise;
	
	void Start ()
	{
		noise = new Perlin ();
	}
	
	void Update () 
	{
		this.transform.localScale = new Vector3(tranScaleX, tranScaleY, tranScaleZ);
		
		MeshFilter meshFilter = this.GetComponent<MeshFilter>();
		Mesh mesh = meshFilter.mesh;
		
		if (baseVertices == null)
			baseVertices = mesh.vertices;
			
		Vector3[] vertices = new Vector3[baseVertices.Length];
		
		float timex = Time.time * speed + xOffset;
		float timey = Time.time * speed + yOffset;
		float timez = Time.time * speed + zOffset;
		
		localForceOffsetDir0 = qOffset0 * localForceOffsetDir;
		localForceOffsetDir1 = qOffset1 * localForceOffsetDir;
		localForceOffsetDir2 = qOffset2 * localForceOffsetDir;
		localForceOffsetDir3 = qOffset3 * localForceOffsetDir;
		
		for (int i = 0; i < vertices.Length; i++)
		{
			Vector3 vertex = baseVertices[i];
			
			// distort upper quarter
			if (vertex.y >= 0.25f)
			{
				vertex += localForceOffsetDir0;
				
				vertex.x += noise.Noise(timex + vertex.x, timex + vertex.y, timex + vertex.z) * meshScaleX;
				vertex.y += noise.Noise(timey + vertex.x, timey + vertex.y, timey + vertex.z) * meshScaleY;
				vertex.z += noise.Noise(timez + vertex.x, timez + vertex.y, timez + vertex.z) * meshScaleZ;			
			}
			
			// distort upper middle quarter 
			else if (vertex.y >= 0.0f && vertex.y < 0.25f)
			{
				vertex += localForceOffsetDir1;
				
				vertex.x += noise.Noise(timex + vertex.x, timex + vertex.y, timex + vertex.z) * meshScaleX;
				vertex.y += noise.Noise(timey + vertex.x, timey + vertex.y, timey + vertex.z) * meshScaleY;
				vertex.z += noise.Noise(timez + vertex.x, timez + vertex.y, timez + vertex.z) * meshScaleZ;			
			}
			
			// distort lower middle quarter
			else if (vertex.y <= 0.0f && vertex.y > -0.25f)
			{
				vertex += localForceOffsetDir2;
				
				vertex.x += noise.Noise(timex + vertex.x, timex + vertex.y, timex + vertex.z) * meshScaleX;
				vertex.y += noise.Noise(timey + vertex.x, timey + vertex.y, timey + vertex.z) * meshScaleY;
				vertex.z += noise.Noise(timez + vertex.x, timez + vertex.y, timez + vertex.z) * meshScaleZ;			
			}
			
			// distort lower quarter
			else 
			{
				vertex += localForceOffsetDir3;
					
				vertex.x += noise.Noise(timex + vertex.x, timex + vertex.y, timex + vertex.z) * meshScaleX;
				vertex.y += noise.Noise(timey + vertex.x, timey + vertex.y, timey + vertex.z) * meshScaleY;
				vertex.z += noise.Noise(timez + vertex.x, timez + vertex.y, timez + vertex.z) * meshScaleZ;			
			}
			
			vertices[i] = vertex;
		}
		
		mesh.vertices = vertices;
		
		if (recalculateNormals)	
			mesh.RecalculateNormals();
		
		mesh.RecalculateBounds();
	}
}