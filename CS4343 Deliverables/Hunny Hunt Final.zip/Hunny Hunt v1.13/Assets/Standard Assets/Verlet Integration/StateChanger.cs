using UnityEngine;
using System.Collections;

// Triggers state change when needed.
// Attach script to a gameObject with a collider with isTrigger = true and rigidBody set to isKinematic and noGravity 
// Or simply use StateChanger prefab
public class StateChanger : MonoBehaviour {
	
	public ParticleManager.FluidState enterState = ParticleManager.FluidState.Compressed;
	public ParticleManager.FluidState exitState = ParticleManager.FluidState.Compressed;
	public bool exit = false;
	
	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag("StateChange"))
		{
			ParticleManager pm = other.gameObject.transform.parent.GetComponent<ParticleManager>();
			pm.updateEmitterState(enterState);
		}
	}
	
	void OnTriggerExit(Collider other)
	{
		if (other.gameObject.CompareTag("StateChange") && exit)
		{
			ParticleManager pm = other.gameObject.transform.parent.GetComponent<ParticleManager>();
			pm.updateEmitterState(exitState);
		}
	}
}
