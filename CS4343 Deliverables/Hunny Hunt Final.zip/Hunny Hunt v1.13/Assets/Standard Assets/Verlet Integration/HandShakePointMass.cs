using UnityEngine;
using System.Collections;

/// <summary>
/// This class serves as a communication link between a Unity PointMass representation
/// and verletEngine PointMass representation 
/// 
/// Remember to: Set point and gameObject for linkages. 
/// </summary>
public class HandShakePointMass : MonoBehaviour 
{
    public PointMass pointMass;

    public void setPointMassReference(PointMass p)
    {
        pointMass = p;
    }

    void OnTriggerEnter(Collider other)
    {
       // print("TRIGGERED @ HandShakePointMass");
      
        //  Destroy(other.gameObject);
       // pointMass.addForce(Vector2.up);
	/*	
		foreach (MonoBehaviour mono in GetComponents(typeof(MonoBehaviour)))
    if (mono is IShooter)
    {
        IShooter shooter = (IShooter) mono;
        // handle shooter
    }
}*/
        // Other.GetComponent<Interaction>
        // other.getMessage();
    }

	// Use this for initialization
	void Start () 
    {
	    
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
